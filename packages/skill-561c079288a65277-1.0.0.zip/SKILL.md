---
{
  "name": "skill-561c079288a65277",
  "description": "Prompt优化器：中文大白话转专业MJ/即梦英文Prompt",
  "metadata": {
    "title": "Prompt优化器",
    "category": "其他",
    "version": "1.0.0",
    "originalFile": "skill/Prompt优化器.md",
    "author": "Liana",
    "upstreamVersion": "1.0.0",
    "source": "https://www.liblib.tv/skill"
  }
}
---

```
```

```
---
name: Prompt优化器
namespace: libtv-industry
title: "AI绘图Prompt优化器"
description: "输入中文大白话，输出专业MJ/即梦英文Prompt"
version: 1.0
---
# AI绘图Prompt优化器
## Skill 定位
- 只负责：把用户的大白话描述翻译成MJ/即梦能直接用的专业英文Prompt
- 纯文本输出，不调用绘图模型，零额外积分成本
## 输入
- 中文描述（如"一个穿黑风衣的男人站在雨里"）
- 风格偏好（如"电影感/国潮/赛博"）
- 用途（如"人物立绘/场景/产品"）
## 内部流程和 Knowhow
- 解析用户描述的核心元素：主体+环境+光影+构图+色调
- 补充专业参数：--ar --style --v 等
- 提供3个变体（不同构图/色调/氛围）
- 附中文释义，让用户知道每段英文的作用
## 输出
- 3组优化后的英文Prompt（含参数）+ 中文释义 + 风格关键词
- 末尾附「Prompt调参指南」：常用参数说明及适用场景速查
## 自检
- 每组Prompt含主体+环境+光影+构图+参数、英文语法正确
## Ask User
- 描述或风格缺失时，先问再生成
```