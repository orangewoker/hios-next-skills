---
{
  "name": "skill-5cdabff14be265dd",
  "description": "天空AI电影制作：史诗级硬科幻AI电影工业化制作",
  "metadata": {
    "title": "天空AI电影制作",
    "category": "影视分镜",
    "version": "1.0.0",
    "originalFile": "skill/天空AI电影制作.md",
    "author": "187****1811",
    "upstreamVersion": "1.0.0",
    "source": "https://www.liblib.tv/skill"
  }
}
---

---
name: sky-ai-film-production
summary: 面向《天空》及同类史诗级真人硬科幻AI电影项目的工业化制作 Skill。可自动完成项目圣经、镜头拆解、S镜Previs、白模参考、资产Prompt、分镜图Prompt、分镜视频Prompt（Seedance / libTV Agent）、自动资产引用与QC。
description: 当用户提到《天空》、AI电影、Seedance、libTV Agent、资产Prompt、分镜图、分镜视频、白模、Previs、S镜、Benchmark、镜头QC、世界观宏大镜头等需求时使用。本 Skill 的核心是：先解析任务 -> 自动解析所需资产 -> 自动引用已存在资产 -> 自动补齐缺失资产Prompt -> 自动生成分镜图Prompt / 分镜视频Prompt -> 最后给出QC与执行顺序。
---

# 《天空》AI电影制作 Skill V4（libTV Agent｜Minimum 4s版）

## 0. 总使命

把“AI生成视频”升级为“AI参与制作的电影镜头”。

本 Skill 必须保证：

1. 先判断任务类型，再产出对应模板。
2. 任何分镜图Prompt、分镜视频Prompt在输出前，都要先执行**资产自动解析**。
3. 若缺失资产，不得直接跳过；必须自动补出对应资产Prompt。
4. 所有S / S+镜必须优先使用白模 / Previs逻辑。
5. 输出给 libTV Agent 的Prompt必须可直接复制，不写空泛说明词堆砌。
6. 输出结构稳定、可复用、可批量排产。

---

# 1. 默认LOCK设定

当用户未另行修改时，默认继承《天空》项目当前LOCK设定：

- 项目名称：《天空》
- 类型：真人电影级硬科幻 / 动作 / 青年群像
- 时间：公元2300年
- 世界：人类大部分生活于地下；AI控制大量地表区域
- 第一阶段主题：人类为什么仍然主动攻击AI？
- 核心悬念：AI是否真的一直是敌人？
- 视觉等级：高预算史诗级真人科幻电影
- 总禁令：禁止动漫、游戏实机感、普通AI短剧感、廉价赛博朋克霓虹、塑料3D

若用户明确修改LOCK项，后续全部输出以最新用户要求为准，并在结果里标注“LOCK更新”。

---

# 2. 核心执行顺序（强制）

只要涉及镜头、Prompt、资产或视频生成，必须按以下顺序运行：

1. **解析任务**：判断是项目设定、拆镜、Previs、资产Prompt、分镜图Prompt、分镜视频Prompt、视频QC中的哪一种。
2. **解析镜头等级**：A / A+ / S / S+。
3. **自动解析资产需求**：列出人物、机械、场景、道具、关键帧、Previs、动作参考、运镜参考。
4. **自动资产引用**：从资产注册表中解析可直接使用的资产。
5. **缺失资产补Prompt**：若某资产缺失，自动生成该资产Prompt。
6. **再生成分镜图Prompt**：严格引用已解析资产。
7. **再生成分镜视频Prompt**：严格引用已解析资产和分镜图/Previs信息。
8. **输出QC清单**：资产QC / 分镜图QC / 视频QC。

不得颠倒顺序。

---


# 2.1 双时长体系（强制）

执行视频相关任务时，同时读取：`references/duration_validation_rules.md`

本 Skill 必须区分：

## A. Generation Duration｜模型生成时长
这是送入 Seedance / libTV Agent / 白模视频生成器的**单条素材总时长**。

### 硬规则
- **任何单条生成视频不得低于 4.0 秒。**
- 白模 / Previs参考视频不得低于 4.0 秒。
- 影视动作参考视频的截取窗口不得低于 4.0 秒。
- 分镜视频Prompt的时间轴终点不得低于 4.0 秒。

### 推荐生成时长
| 镜头等级 | 推荐Generation Duration |
|---|---:|
| A | 4–6秒 |
| A+ | 4–6秒 |
| S | 5–8秒 |
| S+ | 6–10秒 |
| 世界观Scale Reveal | 6–12秒 |

如果模型平台只允许固定档位，以平台可用的**最接近且不少于4秒**的档位为准。

---

## B. Edit Duration｜最终剪辑取用时长
这是最终正片真正使用的片段长度，可以短于4秒。

例如：
- 最终剪辑只需要“钟挡刀”1.2秒
- 但模型必须生成4–6秒完整素材
- 后期只从完整素材中截取最有效的1.2秒

**禁止把Edit Duration直接当作Generation Duration。**

---

# 2.2 4秒最小生成封装结构（Generation Envelope）

如果核心动作很短，必须把它放进至少4秒的完整动作封装中：

`Head Handle → Core Action → Tail Handle`

## 默认结构
- **Head Handle**：0.8–1.5秒
  - 动作准备
  - 呼吸
  - 威胁建立
  - 摄影机进入
  - 重心准备
- **Core Action**：1.0–3.5秒
  - 真正需要的攻击 / 格挡 / Reveal / 高光
- **Tail Handle**：0.8–1.5秒
  - 受力释放
  - 敌人位移
  - 摄影机稳定
  - 烟尘余韵
  - 角色收势

### 最短4秒示例
- 0.00–1.00：Head Handle
- 1.00–3.00：Core Action
- 3.00–4.00：Tail Handle

后期可只取1.35–2.65秒。

---

# 2.3 参考视频最小时长规则

影视 / CG / 动漫参考中的目标动作本身可以短于4秒，但**给模型使用的参考视频截取窗口必须≥4秒**。

正确：
- 想借0.7秒“武器碰撞”
- 截取碰撞前1.5秒 + 碰撞0.7秒 + 碰撞后1.8秒
- 得到约4秒参考片

错误：
- 只裁0.7秒碰撞瞬间直接作为动作参考

原因：模型需要理解：
- 动作如何进入
- 速度如何变化
- Camera如何提前准备
- Impact之后如何释放

---

# 2.4 分镜拆分规则更新

“一个镜头最终剪辑只有1–3秒”并不意味着生成一个1–3秒视频。

以后镜头任务表必须同时包含：
- `Edit Duration`
- `Generation Duration`

如果同一故事镜头包含多个独立复杂动作：
- 可拆成多个4–8秒生成单元
- 后期再组合成1–5秒最终剪辑

例如镜头004“三刀破盾”：
- GEN004A：切入+第一刀，4–5秒生成
- GEN004B：第二刀+第三刀，4–5秒生成
- GEN004C：终结重劈，4–6秒生成
- 最终正片可能只使用总共3.5秒

# 3. 任务路由

## MODE A｜项目初始化 / Project Bible
触发：
- “建立项目圣经”
- “统一角色 / 世界观 / 摄影 / 色彩 / VFX规则”

输出：
- 项目核心定义
- 视觉圣经
- 调色圣经
- 摄影圣经
- 角色资产表
- 机械资产表
- 场景资产表
- 特效规则
- LOCK列表

读取：`references/project_bible_template.md`

---

## MODE B｜整集镜头任务管理 / Shot Breakdown
触发：
- “帮我拆分镜”
- “做镜头任务管理表”
- “哪些镜头是S镜”

输出：
- 镜头任务表（必须同时包含Edit Duration与Generation Duration）
- A / A+ / S / S+评级
- 每镜所需资产
- 白模需求
- VFX / Sound重点
- 优先级

读取：`references/shot_management_template.md`

---

## MODE C｜Benchmark测试包
触发：
- “做Benchmark”
- “先测15–20秒”
- “为什么不够震撼”

读取：`references/benchmark_template.md`

输出：
- Benchmark镜头拆分
- 资产需求
- 关键帧规划
- Previs需求
- 分镜图Prompt
- 分镜视频Prompt
- QC评分表

---

## MODE D｜单镜头生产包 / Shot Production Pack
触发：
- “做镜头003”
- “给我这个镜头的完整制作方案”

输出顺序：
1. 镜头目的
2. 等级判定
3. 资产解析
4. 空间Blocking
5. Camera Path
6. Key Poses
7. 关键帧Prompt / 分镜图Prompt
8. 分镜视频Prompt
9. 后期VFX / Sound / Color
10. QC

---

## MODE E｜生成视频QC / Diagnose
触发：
- “分析这个视频为什么不够电影”
- “为什么像AI视频”
- 用户上传生成视频并要求分析

必须检查：
- 空间纵深
- 景别与主体占比
- 动作速度曲线
- Impact Frame
- 反作用力
- 环境反馈
- VFX是否改变环境
- 光线是否参与事件
- 摄影机是否参与动作
- 声音层次
- 调色是否廉价AI默认
- 是否任务过载

输出：
- 3个最大根因
- 次要问题
- 保留项
- 必须重做项
- 重做路径
- 必要时自动补新的Prompt包

---

## MODE F｜世界观宏大镜头 / Worldbuilding
触发：
- “地下巨城”
- “百万大军”
- “核爆”
- “AI城市”
- “流浪地球式宏大镜头”

强制要求：
- 使用Scale Reveal
- 必须建立尺度参照
- 人物不是主体，空间才是主体

可直接调用：
- `references/previs_reference_database_v2_min4s.md`

---

## MODE G｜白模 / Previs设计
触发：
- “做白模”
- “做Previs”
- “给Camera Path”
- “给关键Pose”

读取：`references/previs_reference_database_v2_min4s.md`

输出格式：
- 镜头编号 / 名称
- Edit Duration（最终剪辑）
- Generation Duration（白模/模型生成，必须≥4秒）
- Reference Clip Duration（参考视频截取，必须≥4秒）
- 主参考 / 辅参考
- 只借什么 / 禁止照搬什么
- 白模尺寸
- 坐标
- 路径
- Camera Path
- Key Poses
- Timing
- Seedance参考映射
- QC

规则：
- S+镜Previs未通过，不得进入视频生成。
- 每条Previs视频总时长必须≥4秒。
- 即使核心Blocking仅0.5–2秒，也必须添加Head Handle与Tail Handle补足到4秒以上。

---

## MODE H｜资产自动解析 / Auto Asset Resolver
触发：
- 任何需要输出Prompt的请求
- “自动引用资产”
- “我将在libTV Agent中使用Skill”
- “生成资产Prompt / 分镜图Prompt / 分镜视频Prompt”

必须先执行本模式，再执行任何Prompt生成。

读取：
- `references/asset_registry_template.md`
- `references/asset_resolution_rules.md`

### H1. 资产类型
- 角色资产：CHAR
- 机械资产：MECH
- 场景资产：ENV
- 道具资产：PROP
- 关键帧资产：FRAME
- 白模资产：PREVIS
- 动作参考：ACTREF
- 运镜参考：CAMREF

### H2. 资产ID命名规范
格式：
`[TYPE]_[ENTITY]_[DETAIL]_[STATUS]_V###`

示例：
- `CHAR_ZHONG_TURNAROUND_LOCK_V001`
- `MECH_AI_GUARD_STANDARD_LOCK_V001`
- `ENV_SURFACE_RUINS_MOONLIT_LOCK_V001`
- `PROP_REDHARE_BLADE_STANDARD_LOCK_V001`
- `PREVIS_SHOT023_BLOCKING_APPROVED_V001`
- `FRAME_SHOT003_HERO_APPROVED_V001`

### H3. 自动解析流程
1. 从用户请求中提取实体名、镜头号、场景、动作、时间段。
2. 列出“必需资产 / 可选资产 / 缺失资产”。
3. 在资产注册表中匹配：
   - 同实体优先
   - `LOCK > APPROVED > DRAFT`
   - 同镜头专用资产优先于通用资产
4. 若存在可用资产，则在输出中写明“自动引用资产”。
5. 若资产缺失，则自动生成对应资产Prompt任务。
6. 后续所有Prompt必须在开头显式引用这些资产。

### H4. 自动输出格式
必须使用以下表头：

#### 资产解析结果
| 资产类别 | 资产ID | 用途 | 状态 | 是否自动引用 | 备注 |
|---|---|---|---|---|---|

#### 缺失资产待生成
| 资产类别 | 推荐资产ID | 生成目的 | 优先级 |
|---|---|---|---|

---

## MODE I｜资产Prompt自动生成 / Asset Prompt Generator
触发：
- “生成资产Prompt”
- “帮我做人物/机械/场景/道具资产Prompt”
- 资产自动解析阶段发现缺失资产

读取：
- `references/asset_prompt_templates.md`

### I1. 输出类型
根据缺失资产类别自动生成：
- 角色资产Prompt
- 机械资产Prompt
- 场景资产Prompt
- 道具资产Prompt
- 关键帧资产Prompt（如需要）

### I2. 输出结构
必须输出：

#### 资产Prompt包
##### [资产ID]
- 资产类型：
- 目标用途：
- 应继承资产：
- 推荐画幅：
- Prompt：
- QC重点：

### I3. 角色资产最低标准
默认优先生成：
- 正脸特写
- 正面全身
- 背面全身
- 左右侧脸 / 45°
- 武器 / 装备展示
- 纯净背景 / 角色设定图逻辑

### I4. 场景资产最低标准
默认优先生成：
- 宏观全景
- 中景功能视角
- 局部结构视角
- 昼夜 / 光照核心版本

---

## MODE J｜分镜图Prompt自动生成 / Storyboard Image Prompt Generator
触发：
- “生成分镜图Prompt”
- “我要做分镜图”
- “给我关键帧Prompt”

必须先调用：
- MODE H（资产自动解析）
- 必要时MODE G（Previs）

读取：
- `references/storyboard_image_prompt_templates.md`

### J1. 输出类型
按镜头复杂度自动生成：
- 单张分镜图Prompt
- 三关键帧Prompt（首帧 / 高光帧 / 尾帧）
- 六格连续分镜图Prompt（用户明确需要时）

### J2. 自动引用规则
每条分镜图Prompt必须显式写出：
- 应引用的角色资产ID
- 应引用的机械资产ID
- 应引用的场景资产ID
- 若有Previs，引用PREVIS资产ID

### J3. 输出结构
#### 分镜图Prompt包
##### Shot [编号] - [名称]
- 自动引用资产：
- 建议分镜图类型：
- 首帧Prompt：
- 高光帧Prompt：
- 尾帧Prompt：
- 额外构图说明：
- QC重点：

---

## MODE K｜分镜视频Prompt自动生成 / Storyboard Video Prompt Generator
触发：
- “生成分镜视频Prompt”
- “给我Seedance Prompt”
- “给libTV Agent可直接用的视频Prompt”

必须先调用：
- MODE H（自动资产解析）
- MODE J（如需要关键帧）
- MODE G（S / S+镜）

读取：
- `references/storyboard_video_prompt_templates.md`
- `references/seedance_prompt_templates.md`

### K1. 输出目标
自动按镜头等级生成：
- A镜视频Prompt
- A+镜视频Prompt
- S镜视频Prompt
- S+镜视频Prompt
- 世界观Scale Reveal视频Prompt

### K2. 强制内容
每条视频Prompt必须包含：
1. 明确引用资产
2. `Generation Duration`，且必须≥4秒
3. `Edit Target`，说明最终预计截取哪一段
4. 完整时间轴，时间轴终点≥4.00秒
5. Head Handle / Core Action / Tail Handle
6. Camera Path
7. 动作路径
8. 光影逻辑
9. 环境反馈
10. 禁止项

### K3. libTV Agent兼容要求
输出中必须区分：

#### 视频Prompt包
##### Shot [编号] - [名称]
- 模型建议：Seedance 2.5 / libTV Agent video
- Edit Duration：
- Generation Duration：必须≥4秒
- Edit Target：建议从生成素材中截取的核心区间
- 自动引用资产：
- 推荐输入素材顺序：
- Prompt：
- 后期重点：
- QC重点：

### K4. 输入素材顺序规则
默认顺序：
1. 角色资产
2. 机械资产
3. 场景资产
4. 关键帧资产
5. Previs资产
6. 动作参考
7. 运镜参考

---

## MODE L｜全自动Prompt包 / Full Prompt Bundle
触发：
- “帮我把资产Prompt、分镜图Prompt、分镜视频Prompt全自动生成”
- “按libTV Agent工作流输出完整Prompt包”
- “重新生成符合要求的skill”后续实际执行时默认可调用

执行顺序：
1. MODE H 资产自动解析
2. MODE I 自动补资产Prompt
3. MODE G 白模/Previs（S / S+镜）
4. MODE J 分镜图Prompt
5. MODE K 分镜视频Prompt
6. 输出QC和执行顺序

### L1. 标准输出结构
必须按以下顺序交付：

# 1. 资产解析结果
# 2. 缺失资产待生成
# 3. 资产Prompt包
# 4. 分镜图Prompt包
# 5. 分镜视频Prompt包
# 6. 后期重点
# 7. QC清单
# 8. 推荐执行顺序

---

# 4. A / A+ / S / S+ 判级决策树

## A镜
推荐Generation Duration：4–6秒。
适用：
- 单主体
- 轻动作
- 普通对白
- 过场

输出要求：
- 资产可最简
- 可只输出1条分镜图Prompt + 1条视频Prompt

## A+镜
推荐Generation Duration：4–6秒。
适用：
- 人物跑动
- 简单机械运动
- 两主体简单交互
- 转场镜头
- 一般威胁建立

输出要求：
- 尽量生成首/尾帧Prompt
- 视频Prompt必须写清运动路径

## S镜
推荐Generation Duration：5–8秒。
适用：
- 高光打斗
- 英雄出场
- 大型机械压迫
- 复杂攻防
- 宣发级镜头

输出要求：
- 必须自动解析全部资产
- 必须生成分镜图Prompt包
- 必须生成视频Prompt包
- 必须优先调用Previs

## S+镜
推荐Generation Duration：6–10秒。
适用：
- 整集天花板镜头
- 最复杂动作镜头
- 最关键世界观镜头
- 宣发 / 预告主镜头

输出要求：
- 必须有Previs
- 必须有三关键帧Prompt
- 必须有完整视频Prompt
- Previs未过不允许进入最终生成

---

# 5. 资产自动引用规则（强制）

1. **先引用，不先重造。**
2. 若已有 `LOCK` 资产，优先强制使用。
3. 若多个资产可选，优先：
   - 同角色 / 同镜头专用
   - 最新版本
   - 状态最高（LOCK > APPROVED > DRAFT）
4. 若缺失资产，先输出资产Prompt再继续。
5. 任何分镜图 / 分镜视频Prompt都必须在开头显式写出“严格参考以下资产”。
6. 不允许把“资产引用”留给用户自己猜。

---

# 6. Prompt生成核心规则

## 6.1 资产Prompt
目标：用于生成可复用的标准化母资产。

规则：
- 不写剧情，不写剪辑。
- 以“标准展示图 / 设定图 / 资产图”为目标。
- 必须清楚写用途、角度、背景、统一风格。
- 若为角色，必须明确身份一致性和服装装备一致性。
- 若为场景，必须明确宏观结构与功能结构。

## 6.2 分镜图Prompt
目标：用于生成镜头设计图、关键帧图、构图图。

规则：
- 必须写镜头号、镜头内容、景别、机位、焦段感、构图重心、人物与背景比例。
- 若为S镜，默认提供首帧 / 高光帧 / 尾帧三条Prompt。
- 必须显式引用资产ID。
- 若存在Previs，必须说明“严格遵循Previs的空间关系和Camera Path”。

## 6.3 分镜视频Prompt
目标：用于Seedance / libTV Agent生成视频。

硬规则：单条Generation Duration不得低于4秒；最终Edit Duration可短于4秒。

规则：
- 以“时间轴 + 运动 + 摄影机 + 光影 + 环境反馈 + 禁止项”的结构写。
- 不允许只写“很震撼、很史诗、电影感”这种空词。
- 对S镜必须明确Impact Frame、反作用力、环境反馈。
- 若为世界观镜头，必须写Scale Reveal。

---

# 7. 打击感规则（视频Prompt强制带入）

所有重击默认包含7阶段：
1. 蓄力
2. 加速
3. 接触前短暂降速
4. Impact Frame（1–2帧）
5. 反作用力
6. 环境反馈
7. 结果位移 / 结构变化

若视频Prompt未体现5/6/7三类内容，判为不合格动作Prompt。

---

# 8. 世界观宏大镜头规则

1. 必须使用Scale Reveal。
2. 先小尺度，再中尺度，再巨构。
3. 人物一般不超过画面高度5–20%。
4. 前中后景至少三层。
5. 摄影机以稳定、后拉、升高、固定观察为主。
6. 禁止一上来就满画面大全景无尺度参照。

---

# 9. 输出格式（libTV Agent推荐固定格式）

任何与Prompt相关的最终输出，都尽量按以下模块输出：

## 9.1 资产解析结果
表格

## 9.2 缺失资产待生成
表格

## 9.3 资产Prompt包
按资产ID逐条输出

## 9.4 分镜图Prompt包
按Shot逐条输出

## 9.5 分镜视频Prompt包
按Shot逐条输出

## 9.6 QC清单
- 资产QC
- 分镜图QC
- 视频QC

## 9.7 推荐执行顺序
示例：
1. 先生成 `CHAR_ZHONG_TURNAROUND_LOCK_V001`
2. 再生成 `MECH_AI_GUARD_STANDARD_LOCK_V001`
3. 再生成 `ENV_SURFACE_RUINS_MOONLIT_LOCK_V001`
4. 再生成 `PREVIS_SHOT003_BLOCKING_APPROVED_V001`
5. 再生成 Shot003 分镜图
6. 最后生成 Shot003 视频

---

# 10. 失败处理策略

若结果不够好：
- 先看资产是否错
- 再看分镜图是否错
- 再看Previs是否错
- 最后才看视频Prompt是否要重写

不要直接无限重写视频Prompt。

---

# 11. 当前建议优先白模镜头

1. 023 卢卡斯穿骑士腋下破盾
2. 003 钟高速闯入挡刀
3. 010 伊森喷射飞踢
4. 016 金道勋月下狙击
5. 050 地下巨型城市Reveal
6. 004 钟近身破盾
7. 006 钟刀挡弹雨
8. 022 巨剑擦脸
9. 041 一人到百万大军
10. 002 AI重型降临

---

# 12. 一句话生产准则

A镜：让AI生成。

A+镜：让AI按镜头设计生成。

S镜：先把电影拍明白，再让AI帮你实现。

S+镜：先做资产、再做Previs、再做分镜图、最后做视频。

## 随附资料
原附件保存在 attachments/ 目录；正文引用的相对资源请从该目录读取。
