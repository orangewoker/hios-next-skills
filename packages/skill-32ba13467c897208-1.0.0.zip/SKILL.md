---
{
  "name": "skill-32ba13467c897208",
  "description": "DeepSeek爆款复刻｜故事片级AI视频：爆款结构拆解→原创故事片级AI视频",
  "metadata": {
    "title": "DeepSeek爆款复刻｜故事片级AI视频",
    "category": "影视分镜",
    "version": "1.0.0",
    "originalFile": "skill/DeepSeek爆款复刻｜故事片级AI视频.md",
    "author": "星拓AI导演",
    "upstreamVersion": "1.0.0",
    "source": "https://www.liblib.tv/skill"
  }
}
---

---

## name: deepseek-baokuan-story-ai description: 将参考视频拆成可验证的镜头功能与节奏，再由 DeepSeek 生成原创故事片级分镜接力包，导入 LibTV 完成实体商家广告、产品片和剧情短视频的同类效果重构。保留镜头功能与观众路径，替换人物、场景、台词、道具和品牌事实；不复写原片表达。

# DeepSeek 爆款复刻｜故事片级 AI 视频

## 为什么叫爆款复刻

这里的“复刻”只复刻爆款的观众路径、节奏和镜头功能，重新创作人物、场景、道具、台词和品牌事实；不复写原片表达。

## 适用场景

适用于实体商家广告、产品演示、剧情短视频、品牌片和概念片。输入一条有权使用的参考视频或逐镜笔记，以及自己的品牌事实、受众和素材。输出给 LibTV 的原创制作包；如果没有可用的 DeepSeek 接口，就把同一提示词粘贴到 DeepSeek，再导入其结构化结果，不假装本 Skill 已调用模型。

## 先锁边界

- 只提取镜头的**功能**：钩子、信息揭示、情绪转折、产品证明、行动号召、节奏和声音关系。
- 不复制原片的台词、独特角色、构图逐帧复刻、音乐、商标或可识别的美术表达。
- 参考素材必须是用户拥有、已获授权或可公开使用的素材。不能用“换名字”掩盖表达复制。
- 事实字段分为 `已确认`、`待补证`、`创作假设`；待补证字段不得写成广告承诺。

## 工作流

### 1. 建立拉片表

为每个镜头生成唯一 `S01`、`S02` 编号，记录：

`开始/结束秒数｜景别｜机位/运动｜主体与动作峰值｜画面信息｜声音（对白/环境/音乐）｜剪辑功能｜入点状态｜出点状态｜可替换变量`。

若无法看清时间码，标记 `timecode_uncertain=true`，不要编造精确秒数。把原片观察和自己的创作决策分在两张表。

### 2. 抽取观众路径

用一句话写出 `hook → proof → turn → payoff → CTA`。同时写出：

- 第一秒发生的可见变化；
- 观众在第一个信息点相信什么；
- 产品/实体商家事实在哪个镜头被证明；
- 声音是否先于画面，J-cut/L-cut 如何服务转场；
- 哪一个镜头失败会让整条片失去意义。

### 3. 让 DeepSeek 产出原创接力包

把下面的提示词与拉片表、品牌事实一起提交：

```text
你是原创广告分镜编剧。只借鉴参考片的观众路径、镜头功能和节奏，不复制台词、角色、构图、音乐、商标或独特美术表达。
请输出 JSON：
{
  "concept": "一句话原创命题",
  "audience_path": ["hook","proof","turn","payoff","cta"],
  "fact_register": [{"fact":"","status":"confirmed|to_verify|assumption","source":""}],
  "shots": [{
    "id":"S01","duration_s":0,"size":"","camera":"","action":"",
    "dialogue_or_voiceover":"","sound_transition":"",
    "function":"hook|proof|turn|payoff|cta","entry_state":"","exit_state":"",
    "replaceable_fields":["subject","place","prop","copy"],"continuity_risk":"low|medium|high"
  }],
  "negative_constraints":["不得复写原片台词","不得使用未证实卖点"],
  "libtv_handoff":["asset_bindings","first_canary_shot","qc_checks"]
}
先解释哪些字段来自参考片的功能抽取，哪些是新创作；缺信息就写 null，不猜。
```

### 4. 做功能等价的替换矩阵

至少替换四类变量：主体、地点、道具、事实/文案。每次替换写 `old_function → new_expression`，例如“原片的高处俯拍=建立规模感 → 用实体商家门头到生产线的连续推进建立规模感”。保留功能，不保留可识别表达。

### 5. 导入 LibTV 前的接力检查

- `S01` 有首帧主体、`S02` 能读取 `S01.exit_state`；
- 人物、产品、场景和声音绑定有唯一名字；
- 每镜只留一个主要动作和一个主要传播目的；
- 先制作最能证明概念的单镜 canary，再决定是否扩展；
- 生成后检查返回媒体，不以提交回执代替画面检查。

### 6. 返回媒体 QC

按镜头检查：主体/产品是否正确、动作峰值是否完成、屏幕方向和接点是否连续、对白与口型是否可用、品牌事实是否仍然准确。发现缺陷时只修一个缺陷并保留原镜头 ID；连续两次同一缺陷，停止扩展，回到资产或提示词层诊断。

## 最小交付

输出 `拉片表`、`观众路径`、`原创接力 JSON`、`替换矩阵`、`canary 记录` 和 `返回媒体 QC`。如果没有真实返回媒体，状态只能写 `TECH_OK_UNPROVEN`，不能写成已完成成片。