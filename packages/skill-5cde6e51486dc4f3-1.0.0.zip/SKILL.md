---
{
  "name": "skill-5cde6e51486dc4f3",
  "description": "建筑图片转漫游动画：上传一张建筑或空间图片，自动生成电影感建筑漫游动画",
  "metadata": {
    "title": "建筑图片转漫游动画",
    "category": "空间建筑",
    "version": "1.0.0",
    "originalFile": "skill/建筑图片转漫游动画.md",
    "author": "SYN",
    "upstreamVersion": "1.0.0",
    "source": "https://www.liblib.tv/skill"
  }
}
---

\## 做什么

上传一张建筑/空间图片，即可自动生成一段建筑漫游动画。支持推近、环绕、穿行、光影变化等电影感镜头，默认输出 16:9 横屏视频。

\## 需要什么输入

\- 一张建筑或空间图片（实景照片/建筑表现图均可）

\- 可选：镜头风格（缓慢推近 / 环绕飞行 / 第一人称漫步 / 镜头上摇 / 穿行门廊 / 光影变化 / 材质特写 / 云镜漂移）

\- 可选：视频时长（默认 6 秒）、分辨率（默认 720p）、是否带声音（默认静音）

\## 怎么做

1\. 调用 libtv CLI 上传图片为 image 节点。

2\. 创建 video 节点，绑定该图片，使用 Seedance 2.0 的 singleImage2video 模式。

3\. 根据用户选择的镜头风格，填入对应的英文建筑漫游 prompt（含 8 套模板）。

4\. 设置参数：ratio=16:9、duration=6、resolution=720p、enableSound=off，提交生成并同步等待。

5\. 从任务终态提取视频 URL，返回给用户。

\## 产出什么

\- 一段可直接播放的建筑漫游动画视频 URL

\- 网页画布查看链接（https://www.liblib.tv/canvas?projectId=&lt;画布UUID&gt;）

\- 可选：调整镜头风格、画幅、时长后重新生成