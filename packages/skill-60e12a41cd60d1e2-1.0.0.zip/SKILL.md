---
{
  "name": "skill-60e12a41cd60d1e2",
  "description": "天空SKY AI电影制作系统：《天空SKY》AI电影制作全套规则",
  "metadata": {
    "title": "天空SKY AI电影制作系统",
    "category": "影视分镜",
    "version": "1.0.0",
    "originalFile": "skill/天空SKY AI电影制作系统.md",
    "author": "187****1811",
    "upstreamVersion": "1.0.5",
    "source": "https://www.liblib.tv/skill"
  }
}
---

## Skill 用途

本工具专为硬科幻电影项目《天空SKY》设计，通过集成项目特定的视觉风格、角色资产（Node Key）、运动系统及物理规则，生成具备高度一致性的AI视频镜头提示词（Prompt），确保角色、武器和场景在不同镜头间呈现统一的院线级质感。

## 适用输入

- 剧本片段描述
- 简易分镜说明或镜头编号
- 场景动作意图与角色行为描述

## 操作步骤

1. **需求解析**：识别输入中的核心角色（如钟、伊森等）及环境背景。
2. **资产匹配**：调用角色专属 Node Key 及武器配置（如赤兔刀、机械拳套）。
3. **动态设定**：根据动作强度确定 Motion Level (M0-M5) 及运镜节奏。
4. **风格注入**：强制应用项目统一的视觉基底参数（如 35mm 变形宽银幕）。
5. **结构化生成**：按照“固定10段结构”输出最终的视频生成提示词。

## 输出要求

输出必须包含以下核心结构：

- **镜头目标**：核心画面叙事目的。
- **主体与资产**：指定角色身份及 Node Key。
- **动作细节**：单一且明确的关键动作，遵循物理逻辑。
- **战斗逻辑**：涉及 TRX-7 射击时必须描述为“独立脉冲弹体”，严禁激光柱。
- **摄影参数**：包含景别、焦段及 ARRI 大画幅等电影感描述。
- **风格基底**：统一使用 `35mm anamorphic widescreen, IMAX color grading, Kodak 500T film grain texture, skin subsurface scattering, volumetric fog, ARRI large format, DaVinci color grade.`

## 核心资产参考

- **钟**：i-ynbh26ebyqct (赤兔刀: i-25bb6sjhtfxm)
- **伊森**：i-nmj6g8vb3ba2 (机械拳套: i-d6u59fqcsua3)
- **TRX-7**：i-cw7mj7femrac (单轮驱动，严禁双足行走)
- **机械野兽**：i-xegzzxh8x28k

## 注意事项

- 优先保证物理真实性，避免浮夸的CG特效感与AI磨皮感。
- 每个镜头只允许一个主要动作，确保AI理解的准确性。
- 严格遵循角色性格特征，如钟的眼神克制、卢卡斯的姿态优雅。