# 附MD07 | 男频后宫·JSON数据与引擎对接

**所属主SKILL：** 男频后宫 | 上架Steam的互动影游\
**版本：** V2.0 融合合规版

## #做什么

本模块为“男频后宫 | 上架Steam的互动影游”的专属JSON数据与引擎对接规范。

解决互动影游“JSON数据与引擎对接失败、变量语法错误、Twine工程无法运行、视频文件命名混乱”的痛点。通过统一的JSON数据结构、Twine/SugarCube工程规范与Adventure Creator配置说明，确保互动影游能落地运行、可直接交付。

## #需要什么输入

**最少提供：**

- 完整节点清单与变量字典
- 结局清单与触发条件
- 视频文件（MP4格式）与Prompt清单

**可选提供：**

- 项目名称与项目ID
- 目标平台（Steam/视频平台/小程序）
- 是否需要输出JSON数据包

## #怎么做

### 一、遵循主MD全局路由表与绝对工作流铁律

本模块执行时，必须严格遵循主MD的【全局 Skill 调用路由表】与【绝对工作流铁律】。JSON数据与引擎对接环节重点参考【顶级游戏开发大师】的节点设计与引擎对接规则。

### 二、JSON数据结构（标准格式）

1. schemaVersion：JSON数据结构版本号，固定为1。
2. projectId：项目唯一ID，由用户自定义。
3. title：项目名称，由用户自定义。
4. variables：变量数组，含变量ID、名称、类型、默认值、最小值、最大值。
5. nodes：节点数组，含节点ID、类型、标题、场景描述、选择、下一节点。
6. endings：结局数组，含结局ID、类型、标题、触发条件。

### 三、变量字典（示例）

1. 综合好感度：ID为v_affection，类型counter，默认0，范围0-100。
2. 羁绊值：ID为v_bond，类型relationship，默认0，范围0-100。
3. 信任度：ID为v_trust，类型risk，默认0，范围0-100。
4. 修罗场值：ID为v_chaos，类型counter，默认0，范围0-100。
5. 势力信任：ID为v_faction，类型faction，默认0，范围0-100。
6. 路线锁定：ID为v_route，类型routeLock，默认null。
7. 定情信物A：ID为v_tokenA，类型item，默认false。
8. 定情信物B：ID为v_tokenB，类型item，默认false。
9. 神秘玉佩：ID为v_jade，类型item，默认false。

### 四、Twine/SugarCube 工程规范

 1. 引擎锁定：SugarCube 1.0.35（唯一，不可更换/升级）。
 2. 禁用格式：Harlowe / Chapbook / SugarCube 2.x。
 3. 建立方式：手动一个一个建节点，禁止使用“导入twee或txt文件”方式。
 4. 变量语法：标准SugarCube set语法，变量赋值格式为 set空格美元符号变量名空格等于号空格值。禁止使用旧格式。
 5. 变量运算：标准SugarCube增量语法，格式为 set空格美元符号变量名空格等于号空格美元符号变量名空格加号空格数值。禁止使用加号等于号的简写。
 6. 条件判断：eq / ne / gt / gte / lt / lte 六个英文关键字，禁止使用数学符号。
 7. 跳转：标准SugarCube goto语法。链接格式为双方括号内写“显示文字 箭头符号 目标段落名”。
 8. 变量命名：美元符号F 代表男主，美元符号E 代表对手，美元符号snap 代表快照，逐字符一致。
 9. 临时变量：也必须用美元符号前缀。禁止裸用 roll 或 read。
10. 保留字禁令：禁止使用 read 作变量名，改用美元符号readv。
11. 随机数：random(1,100)，禁止 either。
12. 排版：相邻宏之间至少留一个空格。
13. 提交前：跑自检清单10条，全部通过才交付。

### 五、Adventure Creator 配置说明

1. 引擎版本：Unity 2021.3 LTS 或以上，Adventure Creator 1.79 或以上。
2. 场景模式：2D Screen。
3. 变量配置：在AC菜单 Variables → Global Variables 逐一创建。
4. 变量类型对应：综合好感度用Integer；羁绊值用Integer；信任度用Integer；修罗场值用Integer；势力信任用Integer；路线锁定用String；定情信物A用Boolean；定情信物B用Boolean；神秘玉佩用Boolean。
5. 节点配置：创建Cutscene资产，添加动作 PlayMovieClip 播放视频文件，添加动作 Turn On Menu 显示选择界面，等待玩家选择，根据选择执行Variable变化加Run Cutscene跳转。
6. 选择界面：菜单类型为 Appear In Screen Space，按钮点击动作列表为变量变化加跳转。

### 六、视频文件命名规范（强制锁定）

 1. N01.mp4：开场·命运相遇。
 2. N02.mp4：选择1·觉醒前态度。
 3. N03.mp4：核心异能觉醒。
 4. N04.mp4：选择2·第一次选择。
 5. N05A.mp4：女主A线·势力判定。
 6. N05B.mp4：女主B线·势力判定。
 7. N05C.mp4：女主C线·势力判定。
 8. N05D.mp4：女主D线·势力判定。
 9. N05E.mp4：隐藏线·势力判定。
10. N06A.mp4：女主A线·质问身份。
11. N06B.mp4：女主B线·要求回报。
12. N06C.mp4：女主C线·私下试探。
13. N06D.mp4：女主D线·撒娇试探。
14. N07A.mp4：女主A线·阵营施压。
15. N07B.mp4：女主B线·出手阻挠。
16. N07C.mp4：女主C线·情感摊牌。
17. N07D.mp4：女主D线·坦白心意。
18. N07E.mp4：隐藏线·全员博弈。
19. N08.mp4：选择5·最终一搏。
20. E01-E05.mp4：正结局。
21. D01-D10.mp4：坏结局。

警告：视频文件名不可更改，必须和代码里的 src 完全一致。大小写也不能错。

### 七、文件结构规范

1. 项目文件夹包含：项目主文件HTML，N01.mp4至N08.mp4，E01.mp4至E05.mp4，D01.mp4至D10.mp4。
2. HTML和所有视频必须在同一文件夹，缺一个视频就黑屏。
3. 项目文件夹命名规范：项目名\_男频后宫互动影游。

### 八、本地测试规范

1. 本地测试：用 VS Code 加 Live Server 插件，右键HTML选 Open with Live Server。
2. 不可用：直接双击HTML（浏览器会拦截本地视频）。
3. 推荐浏览器：Chrome 或 Edge。

### 九、避坑清单（最容易出错）

1. 变量显示在屏幕上：原因变量写在普通节点里，解决方案为必须写在StoryInit节点。
2. 黑屏：原因起始节点没设为起始片段，解决方案为右键节点设为起始片段。
3. 视频无法播放：原因直接双击HTML，解决方案为用Live Server打开。
4. 所有结局都跳同一个：原因用了错误的跳转语法，解决方案为ENDING_CHECK全部用标准goto语法。
5. 引擎报错：原因用了SugarCube 2.x语法，解决方案为只用SugarCube 1.0.35。

### 十、子级专属提示词模板（示例）

```text
节点ID：N05A
JSON输出：
节点id为N05A，类型normal，标题为女主A线势力判定，
场景描述为时间重启，异能光柱从虚空压下，女主A降临，
选择为空，下一节点为N06A。
Twine代码：
video标签引用N05A.mp4，
继续链接指向N06A。
```