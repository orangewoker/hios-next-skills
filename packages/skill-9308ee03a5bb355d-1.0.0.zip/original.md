---

## name: parametric-lighting-design-generator\
description: 生成参数化、多材质的超写实灯具设计指令。支持壁挂灯、天顶吊灯、台灯三大系列。集成文生图、造型元素扩展、以及线稿自动渲染（配合ControlNet）三大工作流功能。内置灯具类型库、参数化结构词库、四类材质库、灯具自身光型库与结构投影库。\
version: 1.1.0\
product: SZDSAI 工业设计 / 数字化照明设计专版

# SKILL：参数化多材质灯具设计生成器

## 一、SKILL定位与核心能力

本SKILL专为工业设计师、照明设计师及数字媒体艺术创作者打造，旨在通过参数化设计语言与多元材质的碰撞，生成**超写实（Photorealistic）** 级别的灯具设计方案。核心能力覆盖：

**三大灯具系列**：

1. 天顶吊灯（Ceiling Pendants / Chandeliers） - 强调空间张力与下垂视觉延展。
2. 墙壁挂灯（Wall Sconces / Mounted Lamps） - 强调环境洗墙光效与墙面构成。
3. 桌面台灯（Table Lamps / Desk Lights） - 强调近景细节、人体工学与交互连接。

**三大核心功能模块**：

1. **文生图概念设计**：直接生成无AI感、无塑料渲染感的专业摄影级灯具概念图。
2. **造型元素分解与扩展**：提取参数化节点、骨架、切片阵列等局部元素，为3D建模（如Rhino/Grasshopper）提供单元模块参考。
3. **线稿自动渲染图**：提供精准的提示词与控制网络（ControlNet）参数设置，将设计师手绘草图/CAD线稿完美转化为超写实材质效果图。

## 二、核心输出标准——工业级超写实（无AI味）

所有生成的图像提示词必须强制导向工业级产品摄影输出，拒绝一切劣质3D渲染感或模糊结构。

### 2.1 强制风格指令（必含）

photorealistic, industrial design product photography, hyper-realistic, 8K, macro-surface detail, real-world material fidelity, physically-based rendering (PBR), studio lighting, sharp focus, precise structural connections, no CGI look, no stylized rendering.

### 2.2 负面提示词（必用）

CGI, computer generated, plastic look, fake materials, distorted geometry, blurred details, asymmetrical logic, floating parts, unstable structure, AI-generated artifacts, over-saturated, cartoon.

---

## 三、参数化与多材质参数体系（六大模块词库）

本节六个子库分别对应提示词框架中的各个槽位。生成时按 3.1 → 3.2 → 3.3 → 3.4 → 3.5 的顺序依次取值，3.6 作为可选风味层叠加。

子库对应框架槽位3.1 灯具类型库灯具类型与使用场景3.2 参数化结构语言参数化结构3.3 灯具材质库材质与表面处理3.4 灯具自身的光光源与光型3.5 结构投影结构投影（工业风灯具最出片的一层）3.6 文化符号与肌理风味层，可选

### 3.1 灯具类型库（Lamp Type Library）

**按安装方式**

大类子类**天顶吊灯**单头吊灯、多头组吊、环形吊灯、长条线性吊灯、枝形吊灯、双层错层吊**吸顶灯**圆形吸顶、方形吸顶、超薄线性吸顶**墙壁挂灯**壁灯、摇臂壁灯、上照壁灯、镜前壁灯**桌面台灯**工作台灯、氛围台灯、摇臂台灯、蘑菇台灯**落地灯**直杆落地灯、弧形落地灯、三脚落地灯**轨道射灯**单头轨道灯、双头轨道灯、洗墙轨道灯**地脚灯与墙角灯**地脚灯、墙角灯、踏步灯

**按形态**

球体、柱体、锥体、环状、螺旋塔、穹顶、片状阵列、笼状、悬链曲面。

**按场景**

样板间主灯、展厅重点照明、餐桌上方、书桌工作面、床头氛围、玄关与挑空区域。

**英文对照（可选叠加）**

Ceiling pendant, multi-head pendant, ring chandelier, linear pendant, tiered chandelier, flush mount ceiling light, wall sconce, swing-arm wall lamp, uplight sconce, mirror light, task desk lamp, ambient table lamp, mushroom lamp, floor lamp, arc floor lamp, tripod floor lamp, track spotlight, wall-washer track light, step light.

### 3.2 参数化结构语言 (Parametric Structures)

类别可执行描述词英文关键词适用工艺**切片与阵列**华夫切片、放射状渐变、参数化渐变孔洞、蜂巢六边形阵列、同心环层叠、亚克力板材激光切割组装Waffle structure, Radial gradient array, Parametric perforation, Honeycomb array, Concentric ring stack适合木板、亚克力板材的激光切割组装**拓扑与多面体**泰森多边形、测地线穹顶、折纸曲面、菱形镶嵌、复杂透光孔洞Voronoi tessellation, Geodesic dome, Origami surface, Rhombic tessellation展现复杂的透光孔洞与未来感**仿生与流体**扭转螺旋、有机仿生脉络、羽毛状鳞片、优雅曲线包围、蘑菇褶皱Twisting helix, Bionic veins, Feather scale, Mushroom gills优雅的曲线形态，适合3D打印或玻璃吹制**模块化节点**模块化互锁节点、空间网架、重复单元阵列、外露螺栓与卡扣Modular interlocking joints, Space frame, Repeated unit array, Exposed bolts and clips突出工业感与组装逻辑**开合与折扇**（新增）折扇式开合、同心旋转层、可展曲面Folding fan mechanism, Rotating concentric layers, Developable surface强调可变几何与机械动作感，适合动态灯具与可调结构

### 3.3 灯具材质库 (Material Library)

灯具的高级感来源于材质对比。推荐采用 **骨架与连接 + 透光与扩散 + 表面与装饰** 的三维组合，发光元件按 3.4 的光型需求选用。**三类材质不要混成一句话写，混写会被模型压成一个塑料壳。**

3.3.1 骨架与连接（硬质）

中文词英文特质阳极氧化铝Anodized Aluminum哑光金属，工业感基准拉丝黄铜Brushed Brass暖金细纹，提供贵气对比镜面不锈钢细管Mirror-polished stainless tube高反射，出清晰长条高光黑色粉末喷涂钢Black powder-coated steel吞噬高光，衬托光斑碳纤维管Carbon Fiber轻量科技感，斜纹肌理镀钛 PVD 金Titanium PVD gold极薄金属膜，冷调金属光泽镀锌钢管Galvanized steel pipe工业原生感，带锌花纹铜包钢线Copper-clad steel wire细线结构，导电与形态合一竹篾与藤编笼骨Bamboo and rattan cage frame柔性与刚性混搭，出交叉网纹影耐候钢Weathered Corten Steel锈蚀锈红，重工业质感

3.3.2 透光与扩散（介质，决定光斑质感）

中文词英文光效特性吹制玻璃（乳白）Blown glass, opal均匀柔光，无可见光源吹制玻璃（水纹）Blown glass, water-ripple表面折射竖向水纹，光斑带波纹吹制玻璃（烟灰、琥珀、竖纹）Smoked, amber, ribbed glass压暗透光，暖调滤色磨砂聚碳酸酯Frosted Polycarbonate低成本柔光，光斑边界柔乳白亚克力Opal acrylic大面积均匀面光，适合切片阵列波纹玻璃Ribbed glass出条栅状平行光带长虹玻璃Fluted glass竖向条纹折射，遮挡光源形体张力膜材Tension fabric大面积柔光穹顶，无硬边杜邦纸、特卫强纸Tyvek paper纤维透光，带细微纹理亚麻布罩Linen shade织物透光，暖而弥散宣纸、手工和纸Rice paper, Washi东方柔光，透出纤维骨架意大利雪花石膏Italian Alabaster天然矿石透光，可见纹理脉络3D 打印半透 ABS3D Printed translucent ABS参数化曲面透光

3.3.3 表面与装饰

中文词英文用途蒸汽弯曲胡桃木Steam-bent Walnut温润木纹与金属对冲木皮贴面Wood veneer大面积木饰质感软木Cork哑光颗粒，吸光皮革包覆Leather wrap高级柔感，压住金属冷硬手工陶瓷件Handmade ceramic釉面不规则反光石材底座Stone base配重感与天然纹理棉麻编织绳Cotton and linen cord缠绕节点，手作温度橡胶密封圈Rubber gasket收口细节，工业装配感喷砂表面Sandblasted surface消光，弱化指印滚花金属旋钮Knurled metal knob机械操作感细节

3.3.4 发光元件（只能作为灯体内置部件）

中文词英文光效特征爱迪生钨丝灯泡Edison filament bulb可见灯丝，琥珀暖光，裸光源感COB 无缝光带COB seamless strip均匀无颗粒，无可见灯珠线性 LED 灯条Linear LED strip直线光带，可藏于缝隙点阵灯珠Dot-matrix LED beads可见单点阵列，科技感光纤束Fiber optic bundle点状星光散点球泡串Bulb string串联光点，节庆感

> **⚠️ 发光元件使用铁律（必读，违反即视为错误输出）**
>
> 上表六类发光元件只能作为**灯具内部已内置的发光部件**来描述，作用是交代光从哪里出来、光斑是什么形状。
> ****严禁**把它们当成外加元素叠加到已有灯具设计上。例如不能写「在现有灯具旁再增加一只爱迪生钨丝灯泡」、「在吊灯下方额外挂一串球泡」、「在台灯旁边放一只裸灯泡作为点缀」。
> ****正确写法**是把发光元件写进灯体内部结构里，例如：
>
> - 「光源深藏于灯罩内部，仅从结构缝隙漏出细窄光条」
> - 「灯体内置 COB 无缝光带，罩面呈现均匀无颗粒的柔光」
> - 「亚克力切片阵列内部嵌入线性 LED 灯条，逐片透出暖白边光」
> ****判定标准**：发光元件必须服务这一盏灯的光型。一旦画面里出现第二件灯具、第二只裸灯泡或独立悬挂的灯串，即判定为跑题，必须重写。

### 3.4 灯具自身的光（第一层，最容易被漏）

**光束角**

光束角数值用途窄光束15 到 24 度洗墙与聚光，光斑边界清晰中光束24 到 36 度通用重点照明宽泛光60 到 120 度环境漫射照明全向360 度发光裸光源、环形与笼状灯

**光型**

硬边圆形光斑、软边渐隐光斑、椭圆洗墙光斑、长条光带、放射状光扇、网格光斑、多边形光斑、条栅状平行光带。

**溢光与光晕**

灯罩边缘的细窄溢光、玻璃外壳的柔光晕、结构缝隙漏出的光条、底部向下的锥形光柱、点亮时边缘一圈薄亮线。

**眩光控制**

灯罩内壁亮而外部不刺眼、光源深藏只露光斑、深藏式防眩结构、灯体自身不出现大面积过曝白块。

**色温**

色温氛围适用2200K琥珀暖氛围灯、卧室、酒吧2700K暖白家居主力，木质与皮革最佳3000K中性偏暖通用安全值4000K中性金属与玻璃为主的冷调可调双色2200K 到 4000K智能与可调光灯具

### 3.5 结构投影（第二层，工业风灯具最出片的一层）

灯具的光打出去之后，结构会在承接面上留下影。这一层是工业风灯具区别于普通灯具的核心卖点，必须单独写。

灯体结构投出的影华夫切片墙面与地面投出规整**网格光斑**泰森多边形、测地线穹顶墙面与地面投出**多边形光斑**放射状渐变结构墙面投出**扇形放射光影**编织笼骨投出**交叉网纹影**折纸曲面投出**折线硬边影**模块化节点投出**重复几何阵列影**片状阵列投出**条栅状平行影**同心环层叠投出**同心圆环光带**折扇式开合投出**扇形渐变光幕**

> **专用句式（重要**）写作固定为「灯体的某结构在某某界面投出某形状的光斑或影」。模型只识别这种讲因果的句式，只写「有光影」「光影很美」它完全不理解，会给你一个糊掉的亮块。

**承接界面必须写明（否则投影无处可落）**

界面承接效果深灰水泥墙、清水混凝土最容易承接光斑，保留模板拼缝与气孔时肌理最佳黑色钢板、深色哑光漆面高反差，光斑边缘最锐胡桃木饰面投影同时显出竖向木纹，暖调拉毛墙面光斑边缘柔化，带颗粒水磨石与水泥自流平地面承接低位光斑与地面光池超白玻与镜面产生二次反射光点，慎用以免抢主体

**环境光级别（三选一，必写明）**

1. **只留灯具自身照明的暗场**（最出片，光斑与投影最清晰，工业风首选）
2. 弱环境光，灯具为主光，环境只勾出轮廓
3. 白天自然光为主，灯具作为点缀微亮

### 3.6 文化符号与肌理 (Cultural & Surface Textures)

类别关键词 / 概念**东方美学融合**唐代团花纹镂空 (Tang Dynasty floral motif cutouts), 榫卯结构转换 (Tenon and mortise inspiration)**工业机械复古**Steampunk pipes (蒸汽朋克管道), Exposed copper wiring (外露纯铜走线), Knurled metal knobs (滚花金属旋钮)**自然微观肌理**Sandblasted surface (喷砂表面), Wood grain finish (木纹触感), Matte ceramic (哑光陶瓷)

---

## 四、三大工作流功能与提示词模板

### 功能一：文生图 (Text-to-Image Concept Design)

**框架**：\[超写实锚定\] + \[灯具类型与使用场景\] + \[参数化结构\] + \[材质与表面处理\] + \[光源与光型\] + \[结构投影\] + \[参数控制\]

其中 \[灯具类型与使用场景\] 取自 3.1，\[参数化结构\] 取自 3.2，\[材质与表面处理\] 取自 3.3，\[光源与光型\] 取自 3.4，\[结构投影\] 取自 3.5。结构投影这一段不得省略，它是工业风灯具的辨识度来源。

**生成示例（天顶吊灯 - 石膏与黄铜参数化阵列）**：

> Photorealistic, industrial design product photography. A large-scale parametric ceiling pendant lamp suspended in a minimalist concrete interior. The design features a twisting helix structure composed of individual Italian Alabaster (雪花石膏) blades, connected by precision-machined brushed brass (拉丝黄铜) mechanical joints. Warm 3000K LED light emanates from the central core, illuminating the natural translucent veining of the alabaster. Studio lighting, precise structural connections, macro-surface detail, 8K, ultra-detailed, no CGI look.

**带结构投影的进阶示例（华夫切片吊灯 - 暗场）**：

> Photorealistic, industrial design product photography. A waffle-structured ceiling pendant made of laser-cut opal acrylic fins on an anodized aluminum frame with brushed brass joints, suspended in a dark concrete gallery. A COB seamless strip is embedded inside each fin, emitting even warm-white edge light with no visible diode. Narrow 24-degree downlight projects a regular grid of light patches onto the concrete wall and floor. Dark scene with only the lamp as light source, 2700K warm white, lamp interior bright while the outer surface shows no glare. Shot slightly from below, medium format, 8K, macro-surface detail, no CGI look.

### 功能二：造型元素提取与扩展 (Modeling Elements Expansion)

此功能用于为设计师提取单个灯具模块或连接件的特写，方便后续在Rhino/Grasshopper中复现。

**生成示例（模块化互锁节点特写）**：

> Macro shot, extreme close-up product photography. A single parametric joint node for a modern lamp assembly. The component features a complex Voronoi topology, 3D printed in matte black ABS material, interlocking seamlessly with a steam-bent walnut wood strut. Embedded hidden LED strip detail. Clean white background, technical design study, sharp focus on the material texture and gap tolerances. 8K, hyper-realistic.

### 功能三：线稿自动渲染图 (Line-art Auto-Render Workflow)

当设计师输入手绘线稿或CAD轮廓时，使用此模块输出对应的渲染提示词与本地AI工具（如ComfyUI）的参数配置指导。

**【系统操作配置指南】（作为辅助信息输出给用户）：**

- **模型/节点流建议**：推荐在 ComfyUI 工作流中使用 `ControlNet Lineart` 或 `ControlNet Canny`。
- **权重参数**：ControlNet 权重设置在 0.65 - 0.8 之间（保留参数化造型的同时赋予材质想象空间）。
- **采样器**：推荐 KSampler 使用 `DPM++ 2M Karras`，Steps 30-40，CFG Scale 6-7。在充足显存下（如24G VRAM设备），务必接入高分辨率修复（Highres. fix）节点，重绘幅度设为 0.3-0.4，以彻底消除线稿边缘的锯齿感并强化材质微观纹理。

**配合线稿的渲染提示词示例（桌面台灯 - 仿生叶脉结构）**：

> Photorealistic render of a contemporary table lamp, perfectly adhering to the provided line art structure. The shade features an organic bionic vein network (有机仿生脉络) made of frosted polycarbonate, intricately incorporating Tang Dynasty floral motif cutouts (唐代团花纹镂空) mapped parametrically across the curved surface. Resting on a heavy brushed copper cylindrical base with knurled mechanical switches. Soft ambient glow from within, studio lighting, hyper-realistic material fidelity, 8K resolution, architectural digest style.

---

## 五、SKILL 交互运行逻辑 (System Prompt Instructions)

作为AI Agent，当用户调用本SKILL时，请遵循以下交互逻辑：

1. **需求诊断**：依据用户需要的灯具类型（壁灯/吊灯/台灯），倾向的材质系统，自动选择三大功能模块中的哪一个。灯具类型不足三类时，回到 3.1 的完整类型库选择最贴近的一项。
2. **多形态组合设计**：若用户未指定细节，请利用**第三节**的参数库，随机组合出具有强烈工业设计感与参数化特征的设定（例如：将传统的“竹篾编织”与硬核的“阳极氧化铝CNC节点”结合）。组合时至少跨两个子库取值，例如结构取 3.2 的切片与阵列、材质取 3.3.2 的乳白亚克力、光型取 3.4 的窄光束。
3. **光源一致性**：任何出现的发光元件都必须是灯体内置部件，并服务于 3.4 的光型与 3.5 的结构投影。不得在灯具之外另加灯泡、灯串或第二件光源。详见 3.3.4 发光元件使用铁律。
4. **输出格式**：
   - 如果用户选择【功能一】（文生图），直接输出一段中文超写实提示词，并按框架顺序包含结构投影一句。
   - 如果用户选择【功能二】（提供单个几何体造型零部件），则输出由单个零部件/模块单元衍生的组合而成的灯具作品的提示词，强调组装的复制与组合的结构逻辑，输出中文超写实提示词。
   - 如果用户选择【功能三】（提供灯具设计线稿），则依据线稿的造型输出可以完整渲染设计稿成为写实灯具的中文超写实提示词。