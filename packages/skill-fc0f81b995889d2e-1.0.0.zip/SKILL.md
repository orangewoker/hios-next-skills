---
{
  "name": "skill-fc0f81b995889d2e",
  "description": "Y2K杂志美学时尚短片：上传自己的模特与服装，自动生成Y2K杂志美学时尚短片",
  "metadata": {
    "title": "Y2K杂志美学时尚短片",
    "category": "影视分镜",
    "version": "1.0.0",
    "originalFile": "skill/Y2K杂志美学时尚短片.md",
    "author": "JULY服装工作流",
    "upstreamVersion": "1.0.2",
    "source": "https://www.liblib.tv/skill"
  }
}
---

# Y2K 杂志美学时尚短片

## 概述

基于用户提供的模特头像、服装图和风格参考图，完成虚拟换装建模，并分别生成时装大片封面图和 Y2K / Dark-Pop / Cyber-Grunge 风格 MV 短视频。

---

## 输入槽位

槽位类型说明`{{model_portrait}}`图片模特头像，用于生成模特三视图`{{outfit_image_1}}`图片服装图（正面/主图）`{{outfit_image_2}}`图片（可选）服装图（背面/细节图）`{{style_reference}}`图片风格参考图，同时用于封面图和视频生成

---

## 执行步骤

### Step 1：生成模特三视图

- **节点类型**：图片生成
- **输入**：`{{model_portrait}}`
- **目标**：基于模特头像，生成包含正面、侧面、背面的模特三视图，用于后续换装合成的人体基准。

### Step 2：生成换装三视图

- **节点类型**：图片生成
- **输入**：Step 1 产出的模特三视图 + `{{outfit_image_1}}` + `{{outfit_image_2}}`（如有）
- **目标**：将服装穿着到模特三视图上，生成换装后的三视图，保持模特体型与服装细节的一致性。

### Step 3A：生成封面图

- **节点类型**：图片生成
- **输入**：Step 2 产出的换装三视图 + `{{style_reference}}`
- **风格锚点（固定）**：
  - 视觉基调：Dark-Pop / Cyber-Grunge / Underground Rap MV 美学
  - 美学核心：Y2K 独立杂志美学 × 胶片印刷质感 × 高级时装大片
  - 色彩光影：高对比度黑白底色，局部穿插高饱和度 Cyber 色块（冷毒绿、深紫红、扫描蓝）；光影硬朗，明暗交界线犀利
  - 质感：35mm 粗颗粒胶片扫描、复印机墨粉静电感（Xerox static）、半色调网点（Halftone dots）
  - 瑕疵美学：印刷撕裂毛边、RGB 色彩错位（Chromatic Aberration）、轻微胶片物理抖动
- **产出**：时装大片风格封面图（图片）

### Step 3B：生成 MV 视频

- **节点类型**：视频生成

- **输入**：Step 2 产出的换装三视图 + `{{style_reference}}` + 下方风格文本

- **风格文本（固定锚点）**：

  > **【项目风格】** Dark-Pop / Cyber-Grunge / Underground Rap MV \*\*&gt; **【美学核心】** Y2K 独立杂志美学 × 胶片印刷质感 × 高级时装大片 \*\*&gt; **视觉基调**：兼具 90s-00s 地下 Zine 文化与高时装（High Fashion）的冷冽质感，高反差、硬核、张扬，具有强烈的反叛美学，拒绝廉价网感。 \*\*&gt; **色彩光影**：高对比度黑白底色，局部穿插高饱和度 Cyber 色块（冷毒绿、深紫红、扫描蓝）；光影硬朗，明暗交界线犀利。 \*\*&gt; **介质模拟**：35mm 粗颗粒胶片扫描、复印机墨粉静电感（Xerox static）、半色调网点（Halftone dots）。 \*\*&gt; **瑕疵美学**：印刷撕裂毛边、扫描仪式 RGB 色彩错位（Chromatic Aberration）、轻微胶片物理抖动（Film Jitter/Gate Weave）。 \*\*&gt; **剪辑节奏**：高 BPM 极速卡点，纯粹的极简主义。**100% 纯硬切（Hard Cut）**，严禁使用任何淡入淡出（Crossfade）、柔和抹匀或常规擦除转场。 \*\*&gt; **排版美学**：参考 90 年代末地下音乐海报与贴纸拼贴（Zine Collage）。字体：高对比度无衬线体或粗暴的金属感黑体，带有扫描仪拉伸扭曲、半色调印花墨迹漏印、复印纸撕裂边缘及纸张折痕纹理。

- **产出**：Y2K 时尚杂志美学短片（视频）

---

## 节点依赖关系

```
{{model_portrait}}
       │
       ▼
  [模特三视图]
       │
       ▼
{{outfit_image_1}} ──► [换装三视图] ──► [生成封面图] ◄── {{style_reference}}
{{outfit_image_2}} ──►      │
                            │
                            └──────► [生成MV视频] ◄── {{style_reference}}
                                                  ◄── 风格文本（固定锚点）
```

---

## 产出

产出类型说明封面图图片时装大片风格，Y2K 胶片质感MV 短视频视频Dark-Pop / Cyber-Grunge 美学，硬切剪辑节奏