---
{
  "name": "skill-ac2421482d232b35",
  "description": "多人场景一致性引擎：多角色同框外貌锁定与跨镜头一致性追踪",
  "metadata": {
    "title": "多人场景一致性引擎",
    "category": "其他",
    "version": "1.0.0",
    "originalFile": "skill/多人场景一致性引擎.md",
    "author": "JokerLL",
    "upstreamVersion": "1.0.0",
    "source": "https://www.liblib.tv/skill"
  }
}
---

# 多人场景一致性引擎

## 这个技能做什么

解决AI视频生成中最头疼的问题：多个角色同框时，每个角色的外貌、服装、身份在切换镜头后还能保持一致。提供从角色定义→提示词锁定→跨镜头追踪→一致性自检的完整方案。

---

## 怎么做

### Step 1：角色档案构建

为每个角色建立独立档案卡，包含5个锁定维度：

维度内容示例面部特征肤色/脸型/发型/发色/眼色/标志性特征pale skin, oval face, short black undercut, sharp jawline, dark brown eyes, thin scar across left eyebrow体型身高/体型/姿态习惯tall lean build, 185cm, slightly hunched shoulders服装上衣/下装/鞋/配饰/颜色/材质dark grey wool coat, black turtleneck, black dress pants, leather boots, silver watch on left wrist标识物独有道具/标记always carries a worn leather journal情绪基调默认表情/微表情习惯default expression neutral with slight frown, habit of touching jawline when thinking

**关键原则：** 每个角色的档案卡一旦确定，在所有后续镜头中**逐字复制**到提示词中，不改动任何一个词。

---

### Step 2：角色区分度设计

多人场景的最大风险是角色混淆。在构建档案时主动制造视觉差异：

**面部差异化矩阵：**

差异维度角色A角色B角色C发色blacksilver greyauburn red发型short undercutlong ponytailmessy bob肤色paletandark brown体型leanmuscularstocky主色dark greynavy blueburgundy标识物leather journalsilver earringround glasses

**规则：**

- 2人场景：至少3个维度差异
- 3人场景：至少4个维度差异
- 4人以上：每个角色必须有唯一标识物 + 独立主色调

---

### Step 3：多人同框提示词结构

**标准结构（按固定顺序排列）：**

```
[场景描述], [角色A完整档案] [角色A动作], [角色B完整档案] [角色B动作], [角色C完整档案] [角色C动作], [空间关系描述], [光影/运镜/技术参数]
```

**空间关系描述模板：**

- A在左/B在右：`Character A stands on the left side of frame, Character B on the right`
- A面对B：`Character A faces Character B across the table`
- 三角构图：`Three characters positioned in triangle composition, A at apex, B and C at base`
- 层次构图：`A in foreground, B in midground, C in background slightly out of focus`

**示例（3人对话场景）：**

> dimly lit tavern interior, wooden tables and candle light, Character A: pale skin man with short black undercut in dark grey wool coat leaning on bar counter, Character B: tan skin woman with long silver grey ponytail in navy blue dress sitting at table holding wine glass, Character C: dark brown skin stocky man with messy auburn bob in burgundy robe standing near fireplace adjusting round glasses, three characters in triangle composition A at left foreground B at center midground C at right background, warm candlelight from below, 35mm lens medium shot, f/2.8, amber and deep shadow palette

---

### Step 4：跨镜头一致性追踪

**镜头切换时的一致性规则：**

切换类型必须保持可变化景别切换（全景→特写）面部特征+发型+标识物服装可被遮挡/部分可见时间切换（白天→夜晚）面部特征+发型+服装光影/色调/背景空间切换（室内→室外）面部特征+发型+服装+标识物背景环境/天气时间跨度（数年后）标识物+面部骨骼结构发型/服装/年龄痕迹

**跨镜头提示词模板：**

```
[新场景描述], [角色档案逐字复制] [新动作], [新空间关系], [新光影/运镜]
```

**关键操作：** 将角色档案作为"常量块"固定，只替换场景和动作部分。

---

### Step 5：角色切换与识别策略

**当镜头只出现部分角色时：**

- 单人特写：使用完整档案 + `solo shot, no other characters visible`
- 双人镜头：使用两人完整档案 + `only these two characters in frame`
- 群体远景：可简化为 `[group of N characters, Character A on left, Character B center, Character C right]` + 各自主色调

**避免角色混淆的硬规则：**

1. 同一镜头中不超过4个有独立档案的角色
2. 超过4人时使用群体描述（`crowd of people`）不逐一定义
3. 每个角色在提示词中出现的位置固定（A总是第一个，B总是第二个）
4. 动作描述紧跟在角色档案之后，不留歧义

---

### Step 6：一致性自检清单

生成提示词后，逐项检查：

- \[ \] 每个角色的面部特征在所有镜头中完全一致（逐字对比）
- \[ \] 发色+发型在所有镜头中完全一致
- \[ \] 服装描述在时间未跳转时完全一致
- \[ \] 标识物在所有应该出现的镜头中都包含
- \[ \] 角色在提示词中的排列顺序固定不变
- \[ \] 空间关系描述清晰，无歧义
- \[ \] 同框角色有足够的视觉差异化（≥3个维度）
- \[ \] 未出现指代代词（he/she/they代替角色名）

**常见一致性崩坏场景：**

1. 角色A的黑发在远景镜头变成棕色 → 原因：远景提示词遗漏了发色
2. 角色B的银耳环在特写中消失 → 原因：特写只写了面部没写配饰
3. 两个角色的服装颜色在暗光下混淆 → 原因：主色调差异不够大
4. 换镜头后角色左右位置互换 → 原因：未指定空间关系

---

## 使用场景

- 短剧/漫剧多角色对话场景
- 同一故事多镜头连续生成
- 多人互动的商业广告
- 系列视频中固定角色IP保持

## 如何使用

1. 告诉系统有几个角色，每个角色的基本设定
2. 系统为每个角色构建5维度档案卡
3. 设计角色间的视觉差异化矩阵
4. 按标准结构生成多人同框提示词
5. 跨镜头时逐字复制角色档案，只替换场景和动作
6. 用一致性自检清单验证

## 输出内容

- 每个角色的完整档案卡（5维度）
- 角色差异化矩阵表
- 多人同框完整提示词（英文）
- 跨镜头提示词序列方案
- 一致性自检报告

## 选择类型

文本

