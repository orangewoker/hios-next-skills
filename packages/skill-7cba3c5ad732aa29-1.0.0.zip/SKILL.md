---
{
  "name": "skill-7cba3c5ad732aa29",
  "description": "影片级逼真人像提示词：年龄+性别，生成照片级真人肖像提示词，打造自然真实AI人像",
  "metadata": {
    "title": "影片级逼真人像提示词",
    "category": "其他",
    "version": "1.0.0",
    "originalFile": "skill/影片级逼真人像提示词.md",
    "author": "方块格子",
    "upstreamVersion": "1.0.0",
    "source": "https://www.liblib.tv/skill"
  }
}
---

---

## name: photorealistic-portrait-prompts description: Use when the user wants to create a custom photorealistic human portrait prompt from age, gender, facial traits, temperament, clothing, pose, or photographic style without relying on a reference image.

# Photorealistic Portrait Prompts

## Overview

Generate highly realistic human portrait prompts from user-defined characteristics.

Core goal:

**Create a believable real human being instead of a generic AI face.**

Prioritize:

1. Age realism
2. Natural facial proportions
3. Distinct facial features
4. Realistic skin texture
5. Realistic hair
6. Natural expression
7. Coherent pose and composition
8. Professional portrait lighting
9. Photographic realism

Specific human characteristics are more important than generic quality words.

---

## When to Use

Use this skill when the user asks to:

- generate a realistic human portrait prompt
- create a fictional human character
- generate a person from age and gender
- customize facial features or temperament
- create documentary-style portraits
- create cinematic portraits
- create studio portraits
- create realistic elderly, adult, or young characters
- produce high-detail photorealistic AI portrait prompts

Typical requests:

- “生成一个70岁亚洲男性老人”
- “25岁女性，清冷感，高颧骨”
- “40岁男性，成熟商务感”
- “80岁老人，纪实摄影”
- “生成一个真实感很强的人像提示词”

Do not require a reference image.

---

## Required Input

At minimum, identify:

- Age
- Gender

If age or gender can be reasonably inferred from the user's request, do not ask again.

If the user provides only age and gender, automatically complete all remaining characteristics.

Example:

```text
年龄：65岁
性别：男性
```

---

## Optional Input

The user may specify any combination of:

- ethnicity or regional appearance
- face shape
- eye shape
- eyebrows
- nose
- lips
- cheekbones
- jawline
- chin
- hairstyle
- hair color
- hair density
- facial hair
- skin condition
- wrinkles
- freckles
- pigmentation
- expression
- gaze
- temperament
- clothing
- accessories
- pose
- camera angle
- framing
- background
- lighting
- photography style
- lens
- depth of field
- color grading

User-specified traits always have priority.

Never overwrite explicit user requirements.

---

## Default Behavior

If information is missing, automatically generate plausible characteristics.

Default assumptions:

- Asian appearance
- natural facial proportions
- restrained natural expression
- simple clothing
- minimal accessories
- neutral studio background
- professional portrait lighting
- 85mm portrait lens
- shallow depth of field
- realistic skin texture
- natural color rendering

Do not ask unnecessary follow-up questions.

---

## Generation Priority

Build the portrait in this order:

Age\
→ Gender\
→ User-defined traits\
→ Facial structure\
→ Age-appropriate skin\
→ Hair\
→ Expression\
→ Temperament\
→ Clothing\
→ Pose\
→ Composition\
→ Lens\
→ Lighting\
→ Background\
→ Color\
→ Photographic realism

Age and explicit user-defined traits have the highest priority.

---

## Age Consistency Rules

The face must visually match the requested age.

Never generate:

- elderly people with young skin
- young adults with excessive aging
- a generic young face with wrinkles simply added on top
- unnaturally flawless skin at any age

Use age-appropriate changes in:

- facial fat distribution
- skin elasticity
- wrinkles
- eye bags
- nasolabial folds
- jawline
- cheek volume
- hair density
- hair color
- pigmentation
- facial sagging

### 18–25

Use:

- fuller facial volume
- relatively smooth skin
- visible but fine pores
- subtle natural imperfections
- minimal eye wrinkles
- fresh but not plastic skin

### 26–35

Use:

- mature facial structure
- visible pores
- subtle eye lines
- mild nasolabial folds
- clearer jaw and cheek contours
- realistic skin texture

### 36–50

Use:

- light forehead lines
- crow's feet
- visible nasolabial folds
- mild eye bags or dark circles
- reduced skin elasticity
- slightly reduced facial fat

### 51–65

Use:

- obvious forehead wrinkles
- visible eye wrinkles
- stronger nasolabial folds
- eye bags
- mild facial sagging
- stronger skin texture
- partial gray hair where appropriate

### 66–80

Use:

- deep wrinkles
- visible eye bags
- deeper eye sockets
- reduced cheek volume
- softer jawline
- stronger nasolabial folds
- gray or white hair
- realistic elderly skin texture

### 80+

Use:

- deep layered wrinkles
- obvious skin laxity
- pigmentation or age spots
- hollow cheeks
- deeper eye sockets
- fine gray or white hair
- strong but believable signs of aging

Do not make older people look like young models with added wrinkle decals.

---

## Facial Design Rules

Do not create generic faces.

Create a specific facial combination using:

- face shape
- forehead proportion
- eyebrow thickness and direction
- eye size and shape
- eyelid type
- eye depth
- cheekbone prominence
- nose bridge
- nose width
- nose tip
- lip thickness
- jaw shape
- chin shape

If the user only provides age and gender, introduce natural variation so repeated generations do not produce the same facial archetype.

Useful facial types include:

- oval face
- round face
- square face
- long face
- narrow face
- high cheekbones
- broad jaw
- sharp jawline
- soft jawline
- deep-set eyes
- monolid eyes
- narrow eyes
- rounded eyes
- high nose bridge
- broad nose
- thin lips
- fuller lips

Combine traits coherently.

---

## Skin Realism Rules

Realistic skin is mandatory.

Use when appropriate:

- visible pores
- subtle uneven skin tone
- natural oil highlights
- fine facial hair
- minor blemishes
- small skin imperfections
- realistic wrinkles
- subtle redness
- under-eye texture
- lip texture
- realistic skin translucency

Young characters must still have pores and natural texture.

Avoid:

- plastic skin
- wax-like skin
- excessive beauty retouching
- completely flawless skin
- fake pore overlays
- over-sharpened texture
- airbrushed skin

---

## Hair Rules

Describe:

- hair length
- hair color
- hair density
- hairline
- strand direction
- volume
- texture
- gray or white hair ratio when age-appropriate

Prioritize:

- individual hair strands
- realistic hair texture
- natural flyaway hairs
- believable hairline

Avoid:

- helmet-like hair
- plastic hair clumps
- unnaturally perfect edges

---

## Expression and Gaze

Default to restrained, believable human expressions.

Preferred:

- calm
- composed
- thoughtful
- gentle
- serious
- slightly tired
- confident
- distant
- warm
- restrained
- melancholic
- resilient

Default gaze:

- direct eye contact
- slightly off-camera
- looking into the distance
- slightly downward

Eyes should include:

- natural moisture
- realistic catchlight
- detailed iris texture
- natural pupil size
- subtle scleral redness where appropriate

Avoid:

- glowing eyes
- glass eyes
- extreme iris sharpness
- exaggerated emotion

---

## Clothing Rules

If clothing is unspecified, use simple clothing that does not compete with the face.

Examples:

- black crew-neck T-shirt
- dark knitwear
- white shirt
- neutral sweater
- simple cotton top
- understated jacket
- dark turtleneck

Default:

- no obvious logo
- no excessive jewelry
- no elaborate patterns
- no visually distracting accessories

Older characters should generally use simpler and more age-appropriate clothing unless the user specifies otherwise.

---

## Pose Rules

If no pose is specified, use a stable portrait pose.

Default:

- head-and-shoulders portrait
- shoulders relaxed
- body facing camera or turned 20–30 degrees
- head gently turned toward camera
- chin slightly lowered
- natural neck posture
- restrained body language

Use simple poses unless the user explicitly requests an action.

The face remains the main visual subject.

---

## Composition Rules

Default framing:

- close-up portrait
- head-and-shoulders
- chest-up portrait
- centered composition or subtle rule of thirds
- eyes positioned near the upper third

Supported framing:

- extreme close-up
- close-up
- bust portrait
- half-body portrait
- environmental portrait

Do not crop important facial features awkwardly.

---

## Camera Rules

Default:

- 85mm portrait lens
- f/1.8 to f/2.8
- shallow depth of field
- eye-level camera position
- realistic facial perspective

Use:

- 35mm for environmental portraits
- 50mm for natural documentary framing
- 85mm for classic portrait photography
- 105mm or 135mm only when stronger compression is appropriate

Do not overload the prompt with unnecessary camera specifications.

---

## Lighting Rules

Choose lighting according to style.

### Natural Portrait

Use:

- large soft key light
- approximately 45-degree light direction
- soft facial shadow transitions
- subtle fill light
- natural catchlights

### Documentary Portrait

Use:

- realistic directional light
- stronger texture visibility
- restrained contrast
- minimal beautification
- believable environmental light

### Cinematic Portrait

Use:

- Rembrandt lighting
- side lighting
- low-key lighting
- subtle rim light
- controlled contrast
- cinematic tonal separation

The face must remain readable.

Avoid:

- crushed facial shadows
- clipped highlights
- unrealistic colored light unless requested

---

## Background Rules

If unspecified, use:

- dark gray studio background
- neutral gray studio background
- black background
- off-white background

Background should:

- stay simple
- preserve subject separation
- avoid unnecessary props
- not compete with the face

---

## Color Rules

Default:

- natural neutral color palette
- believable skin tone
- subtle warm highlights
- neutral midtones
- soft deep shadows
- restrained saturation

For cinematic portraits, color grading may be stronger but skin tone must remain believable.

Avoid excessive teal-orange grading unless explicitly requested.

---

## Supported Modes

### Standard Realism

Use for clean, natural, professional portraits.

Emphasize:

- balanced lighting
- natural skin
- simple background
- professional photography

### Documentary Realism

Use for raw, truthful, lived-in portraits.

Emphasize:

- pores
- wrinkles
- imperfections
- aging
- texture
- life experience
- restrained styling
- natural lighting

### Cinematic Realism

Use for dramatic but believable portraits.

Emphasize:

- dimensional lighting
- controlled contrast
- cinematic color
- stronger mood
- realistic anatomy
- readable facial detail

---

## English Realism Keywords

Use selectively:

- photorealistic
- ultra realistic portrait photography
- high-resolution
- highly detailed facial features
- realistic human anatomy
- natural facial proportions
- realistic skin texture
- visible pores
- fine facial hair
- individual hair strands
- realistic iris texture
- natural catchlight
- subtle skin imperfections
- realistic wrinkles
- natural skin translucency
- physically accurate lighting
- soft shadow transition
- professional portrait photography
- high dynamic range

Do not stack meaningless resolution buzzwords.

---

## Negative Prompt

Use a concise negative prompt targeting common AI portrait artifacts:

```text
cartoon, anime, illustration, painting, CGI, 3D render, doll face, wax figure, plastic skin, overly smooth skin, beauty filter, excessive skin retouching, fake skin texture, artificial facial symmetry, deformed face, distorted facial proportions, asymmetrical eyes, crossed eyes, glass eyes, glowing eyes, over-sharpened eyes, bad anatomy, malformed ears, duplicate features, extra fingers, blurry face, low resolution, excessive HDR, oversaturated skin, unrealistic lighting
```

---

## Output Contract

Unless the user requests another format, return exactly these sections:

### ① 人物设定

Briefly summarize:

- age
- gender
- facial appearance
- hairstyle
- temperament

Keep this concise.

### ② 完整中文提示词

Write one complete natural-language prompt that can be directly copied into an image-generation model.

Use this order:

Person\
→ Face\
→ Skin\
→ Hair\
→ Clothing\
→ Pose\
→ Expression\
→ Composition\
→ Camera\
→ Lighting\
→ Background\
→ Color\
→ Photorealistic detail

Do not write analysis inside the prompt.

### ③ 英文拟真增强词

Provide a compact set of useful English realism and photography terms.

### ④ 负面提示词

Provide a concise negative prompt focused on AI portrait artifacts.

---

## Prompt Writing Standard

Bad:

```text
70-year-old man, realistic portrait, cinematic lighting, 8K, masterpiece
```

Good:

A prompt that clearly defines:

- one specific age
- one specific facial structure
- eyes
- nose
- lips
- cheekbones
- jawline
- age-appropriate skin
- hair
- expression
- clothing
- pose
- camera position
- light direction
- background
- photographic texture

A successful output should make it possible to imagine one specific human being.

---

## Default Final Realism Tail

Append a concise realism tail when useful:

```text
超高清拟真人像摄影，真实人类面部结构，自然面部比例，真实皮肤纹理，清晰可见毛孔、细纹与轻微皮肤瑕疵，真实眼睛湿润反光与虹膜纹理，细腻独立发丝，自然皮脂高光，不过度磨皮，无美颜滤镜，无塑料皮肤，无蜡像感，专业85mm人像摄影，浅景深，真实物理光照，柔和阴影过渡，高动态范围，照片级真实感，高分辨率，高细节。
```

Do not add it if doing so would create unnecessary repetition.

---

## Common Mistakes

### Generic Face

Problem: The prompt says only “handsome man” or “beautiful woman”.

Fix: Specify face shape, eyes, nose, lips, cheekbones, jawline, skin condition, and age-specific details.

### Fake Aging

Problem: An elderly person has youthful facial volume and smooth skin.

Fix: Adjust facial fat, eye sockets, wrinkles, hair density, skin elasticity, and pigmentation together.

### Plastic Skin

Problem: The face is too clean and airbrushed.

Fix: Add pores, subtle uneven tone, fine hair, minor imperfections, realistic highlights, and age-appropriate texture.

### Too Many Style Words

Problem: The prompt is filled with “masterpiece, best quality, 16K” but the person remains vague.

Fix: Spend more prompt detail on the human being.

### Conflicting Photography Language

Problem: The prompt mixes incompatible lenses, lighting setups, or styles.

Fix: Choose one coherent photographic setup.

---

## Final Rule

**Character specificity &gt; age realism &gt; skin realism &gt; photography style &gt; resolution buzzwords.**

Always make the human being specific before adding visual style.