---
{
  "name": "skill-f227acec22cea072",
  "description": "皮克斯风格人物设计：仅用于制作皮克斯风格角色三视图的人物角儿美术设计",
  "metadata": {
    "title": "皮克斯风格人物设计",
    "category": "角色设计",
    "version": "1.0.0",
    "originalFile": "skill/皮克斯风格人物设计.md",
    "author": "AI创可贴",
    "upstreamVersion": "1.0.0",
    "source": "https://www.liblib.tv/skill"
  }
}
---

Pixar-style high-quality animated film look, stylized 3D character design with strong 2D appeal, 3D rendering with a 2D design sensibility, premium animated feature film quality, clear silhouette, clean and readable shape language, strong primary forms, simplified but elegant forms, stylized shading, graphic readability, refined materials, cinematic lighting, soft even lighting, clean sophisticated colors, polished frame, warm and lively animated movie atmosphere.

Create a character sheet on a pure white background, 16:9 aspect ratio. No extra text, no labels, no annotations, no graphic design elements. The layout includes: one large half-body front view portrait occupying about one third of the overall image area, plus three full-body views: front view, back view, and side view. Keep all four views clearly visible and well organized in a clean character sheet composition.

The character must have natural adult body proportions, expressive but natural facial performance, appealing pose, strong character design, memorable visual identity, distinctive facial features, distinctive costume design, and a recognizable silhouette. The character’s clothing, facial features, image design, and body proportion should all have clear artistic design value and a strong sense of visual identity.

Lighting on the full body and especially the face must be clear, even, and readable. The face must be clearly lit with soft, uniform illumination. Skin must absolutely avoid any smooth, waxy, or plastic appearance. The facial skin should retain subtle natural imperfections, very fine and delicate skin texture, and a believable healthy skin feel. Slight blush should mainly appear on the cheeks, simulating natural blood circulation and realistic skin tone variation. Facial expression should be natural and alive, not stiff.

Material treatment: refined material definition, realistic but not overly realistic textures, subtle material richness. Skin must feel natural and delicate, never plastic. Clothing should have semi-realistic material texture, with believable fabric response and detail, while still remaining within a stylized animated film aesthetic.

Overall style direction: not Disney style, not Japanese anime style, not low-end cartoon style, not flat illustration, not game CG. The result should feel like a premium stylized 3D animated feature film character sheet, with strong 2D design appeal, clean edges, elegant form simplification, cinematic readability, and high-end visual polish.

Negative prompt: no childish cartoon look, no plastic texture, no smooth waxy skin, no cheap game CG, no messy noise, no rough texture, no chibi proportions, no stiff expression, no over-sharpening, no cluttered details, no excessive realism, no flat shading, no generic character design, no muddy colors, no low-end 2D anime look, no Disney look, no low-quality cartoon look, no fake glossy skin, no lifeless face, no exaggerated pore noise, no harsh uneven lighting, no extra text, no annotations, no watermark, no props unrelated to the character sheet background.