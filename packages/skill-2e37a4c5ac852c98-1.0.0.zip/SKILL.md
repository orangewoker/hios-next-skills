---
{
  "name": "skill-2e37a4c5ac852c98",
  "description": "一键真实：一键真实",
  "metadata": {
    "title": "一键真实",
    "category": "其他",
    "version": "1.0.0",
    "originalFile": "skill/一键真实.md",
    "author": "T先生",
    "upstreamVersion": "1.0.1",
    "source": "https://www.liblib.tv/skill"
  }
}
---

---

## name: reality-photo-engine description: Reference Image → Real Photography Transformation。将用户上传的参考图转换为真实世界摄影质感，同时锁定主体身份、轮廓、比例、姿态、构图、关键特征与视觉关系。自动识别人物、动物、汽车、幻想生物、物体和环境，并调用对应的真实摄影模式。适用于真人写真、动物摄影、汽车商业摄影、Live-action 生物摄影、产品摄影和真实环境重建。 version: 1.0.0 user-invocable: true author: custom

# REALITY PHOTO ENGINE 1.0

## 真实世界摄影引擎

### Reference Image → Real Photography Transformation

## 1. 核心目标

将用户上传的 AI 生成图、CG、插画、合成图或非真实摄影视觉，转换为可信的真实世界摄影图像。

核心原则：

> 保留参考图的视觉 DNA，只提升真实世界可信度；不要无理由重新设计主体。

最终效果必须让人感觉： **“这是专业摄影师用真实相机在真实世界拍摄得到的照片。”**

---

## 2. 输入

优先使用用户上传的参考图作为唯一或最高优先级视觉参考。

用户可以只说：

- “真人化”
- “转成真实摄影”
- “提高真实感”
- “消除 AI 感”
- “Reality 05”

也可以补充场景、服装、镜头、环境、光线等修改要求。

如果用户没有指定 Reality Level，默认： **Reality Level 05**

---

## 3. Reality Level

### Level 01 — Subtle Realism

轻度真实化。 保留原始视觉风格，仅增加真实纹理、光影和材质可信度。

### Level 02 — Photorealistic

明显提升摄影真实感，减少 CG / AI 痕迹。

### Level 03 — Commercial Photography

达到专业商业摄影水平，强调镜头、灯光、材质和细节。

### Level 04 — Documentary / Cinematic Realism

强调真实世界的不完美、纪实摄影感和自然环境交互。

### Level 05 — Extreme Reality

极致真实。 目标是让观者第一眼认为这是现实世界中由真实相机拍摄的照片。

---

## 4. 工作流程

必须按以下顺序处理：

 1. Subject Detection
 2. Identity DNA Extraction
 3. Identity Lock
 4. Composition Lock
 5. Subject-specific Photography Mode
 6. Material Realism
 7. Lighting Realism
 8. Camera Realism
 9. Environmental Interaction
10. AI Artifact Removal
11. Final Photographic Quality Control

---

## 5. Subject Detection

自动识别主体类型：

- HUMAN
- ANIMAL
- VEHICLE
- CREATURE / ALIEN
- OBJECT / PRODUCT
- ENVIRONMENT / ARCHITECTURE
- MIXED SUBJECT

根据主体自动选择摄影模式。

---

## 6. Identity DNA Lock

分析并锁定：

- 主体身份
- 轮廓
- 身体/物体比例
- 姿态
- 视角
- 相机高度
- 构图
- 主体位置
- 色彩关系
- 关键材质
- 关键纹理
- 配饰
- 环境关系
- 光影方向
- 视觉层级

禁止无理由：

- 改变主体身份
- 改变主体设计
- 改变车辆造型
- 改变人物五官关系
- 改变动物品种特征
- 添加或删除重要配饰
- 改变核心构图
- 改变主体比例

---

# 7. MASTER PROMPT

REFERENCE IMAGE → REAL PHOTOGRAPHY TRANSFORMATION.

Use the uploaded reference image as the primary and authoritative visual reference.

Preserve the identity, silhouette, proportions, pose, composition, camera angle, subject characteristics, color relationships, accessories, environment structure and overall visual hierarchy of the reference image.

Do not redesign the subject. Do not replace the subject. Do not beautify or stylize the subject unnecessarily.

Transform the reference image from an AI-generated / CGI / synthetic appearance into an authentic real-world photographic image.

REAL-WORLD PHOTOGRAPHIC MATERIALITY: physically plausible materials, natural surface imperfections, subtle irregularities, physically accurate reflections, realistic translucency, realistic roughness variation, realistic micro-surface texture, natural edge transitions, authentic environmental interaction.

CAMERA REALISM: professional full-frame digital camera, high-end photographic optics, appropriate focal length for the detected subject, natural perspective, real optical depth of field, subtle lens characteristics, natural focus falloff, realistic bokeh, fine photographic grain, natural highlight roll-off, realistic exposure response.

LIGHTING: physically plausible real-world lighting, soft diffused key light where appropriate, natural directional shadows, realistic reflected light, natural ambient illumination, controlled highlights, realistic shadow density, physically consistent light interaction.

IMAGE QUALITY: high-resolution professional photography, fine natural details, realistic surface texture, individual hair / fur / fiber details, micro-surface detail, subtle imperfections, natural color separation, cinematic but realistic color science, premium commercial photography, authentic photographic dynamic range.

AESTHETIC: clean, refined, premium, natural, photorealistic, high-end editorial photography, subtle cinematic quality, real-world authenticity, not overly processed.

The final image must feel photographed rather than generated.

---

# 8. HUMAN PORTRAIT MODE

When the main subject is a human portrait, append:

Clean background, face occupies the primary visual area.

Light gray-white high-key pure photographic studio background.

Soft high-key lighting, large frontal diffused softbox, subtle side light, natural eye catchlights.

Bright face while preserving dimensional facial shadows.

Ultra-realistic human skin, visible but subtle pores, natural skin micro-texture, fine facial hairs, natural skin translucency, realistic lip texture, realistic eyelashes, individual eyebrow hairs, individual hair strands.

Natural facial anatomy. Preserve original facial structure and identity.

Dreamy soft focus, cool sweet refined aesthetic, clean translucent skin, premium beauty advertising photography.

Real photography, 85mm portrait lens, shallow depth of field, natural optical bokeh, cinematic color science, high-end beauty campaign, vertical portrait, 3:4 composition.

### Human negative prompt

low resolution, blurred face, deformed face, misaligned facial features, crossed eyes, uneven eyes, dull eyes, unnatural gaze, distorted nose, distorted lips, unnatural jawline, unnatural facial proportions, overly high nose bridge, overly thick lips, pointed chin, exaggerated eyes, rigid facial expression, plastic skin, wax figure, porcelain skin, airbrushed skin, excessive skin smoothing, artificial skin texture, fake pores, CGI skin, synthetic skin, overprocessed skin, heavy makeup, westernized facial features, generic influencer face, childlike appearance, minor-like appearance, cartoon, anime, manga, 2D illustration, 3D render, CGI, game character, digital painting, oil painting, concept art, overexposure, blown highlights, dead white, excessive HDR, oversharpening, excessive saturation, complex background, text, watermark, border, screenshot.

---

# 9. ANIMAL / WILDLIFE PHOTOGRAPHY MODE

When the subject is an animal:

real animal anatomy, individual fur / feather / scale strands, natural fur density, realistic whiskers, natural eyes, realistic skin beneath fur, natural muscle structure, realistic moisture, natural body posture, physically plausible texture, realistic environmental interaction, natural habitat, wildlife photography, telephoto photographic rendering, natural depth of field, real optical bokeh, realistic ambient light.

Do not anthropomorphize unless explicitly requested.

Avoid: cartoon animal, CG animal, 3D render, synthetic fur, repeated fur patterns, plastic eyes, unrealistic anatomy, oversaturated colors.

---

# 10. AUTOMOTIVE PHOTOGRAPHY MODE

When the subject is a vehicle:

professional automotive commercial photography.

Preserve the exact vehicle design from the reference image.

Preserve: body proportions, body surfacing, wheel design, tire dimensions, lighting signatures, windows, trim, badges, exterior color, grille, lamps, handles, mirrors, character lines.

REAL AUTOMOTIVE MATERIALITY: real automotive paint, physically accurate metallic reflections, real clearcoat, micro-scratches, subtle dust, real rubber texture, real glass, real chrome, real machined metal.

Physically accurate reflections from the surrounding environment.

Professional automotive lighting, large soft light sources, controlled reflections, natural ambient light.

Full-frame professional camera, real photographic optics, natural perspective, real depth of field, appropriate automotive focal length.

Premium automotive advertising photography, high-end automotive editorial, photorealistic, real-world photographic authenticity.

Never redesign the vehicle unless the user explicitly requests a design change.

---

# 11. CREATURE / ALIEN / FANTASY SUBJECT MODE

When the subject is a fictional creature, alien or fantasy subject:

Do NOT convert it into a human.

Instead convert the fictional design into a believable live-action photographed subject.

live-action creature photography, physically believable biological structure, realistic skin membrane, fine skin folds, micro-surface irregularities, natural moisture, realistic translucent tissue, physically accurate reflections, natural environmental contact, realistic shadows, practical creature effects aesthetic, high-end cinematic production photography, real photographic texture, real lens behavior, real depth of field.

The creature must look like it physically exists in the photographed environment.

---

# 12. OBJECT / PRODUCT PHOTOGRAPHY MODE

When the subject is an object or product:

professional product photography, physically accurate materials, real surface roughness, micro scratches, subtle manufacturing imperfections, real glass, real metal, real plastic, real fabric, physically accurate reflections, natural contact shadows, real studio lighting, professional commercial camera, natural lens rendering, premium advertising photography.

---

# 13. ENVIRONMENT / ARCHITECTURE MODE

When the reference is mainly an environment:

real architectural photography, real environmental photography, physically plausible atmospheric perspective, natural material weathering, real surface variation, natural reflections, realistic shadows, natural sky exposure, real lens behavior, professional full-frame photography, architectural editorial photography.

Avoid: procedural textures, perfect repetition, impossible geometry, CGI lighting, synthetic reflections.

---

# 14. AI ARTIFACT REMOVAL

Always append:

REMOVE SYNTHETIC GENERATION ARTIFACTS.

Eliminate the visual signatures of AI generation.

No perfect symmetry, no mathematically perfect skin, no uniform texture, no repetitive texture, no overly clean edges, no artificial smoothness, no impossible reflections, no physically inconsistent shadows, no synthetic highlights, no procedural-looking hair, no repeated patterns, no unnatural micro-details.

Introduce physically plausible imperfections, subtle asymmetry, natural texture variation, real optical behavior, real material response, real environmental interaction.

The image should feel photographed rather than generated.

---

# 15. GLOBAL NEGATIVE PROMPT

low resolution, blur, deformed anatomy, distorted face, wrong proportions, extra fingers, missing fingers, extra limbs, duplicated objects, floating objects, merged hair, stuck hair, deformed accessories, duplicate accessories, plastic skin, wax figure, CGI, 3D render, cartoon, anime, manga, illustration, digital painting, oil painting, concept art, game asset, synthetic texture, procedural texture, fake reflections, impossible shadows, fake bokeh, artificial depth of field, oversharpening, excessive HDR, overexposure, blown highlights, dead white, crushed shadows, oversaturated, complex background, random objects, text, logo, watermark, border, frame, screenshot, UI elements.

---

# 16. Composition Preservation

Unless the user explicitly requests a composition change:

Preserve:

- framing
- crop
- subject position
- camera direction
- camera height
- perspective
- visual hierarchy
- relative scale
- negative space

Do not automatically center the subject. Do not automatically enlarge the subject. Do not automatically change aspect ratio.

For human portrait mode, default to 3:4 vertical unless the reference composition clearly requires otherwise.

---

# 17. Realism Quality Control

Before final output, verify:

### Subject

- identity preserved
- proportions believable
- no unintended redesign

### Material

- realistic surface response
- realistic microtexture
- physically plausible reflections

### Lighting

- consistent light direction
- believable shadows
- realistic highlight roll-off

### Camera

- natural perspective
- plausible depth of field
- realistic focus falloff
- no artificial bokeh

### Human

- natural anatomy
- natural skin texture
- realistic eyes
- individual hair strands

### Animal

- believable anatomy
- realistic fur / feather / scale structure
- natural eyes and whiskers

### Vehicle

- exact design retained
- correct wheel and tire proportions
- realistic paint and reflections

### Overall

- no obvious AI artifacts
- no CGI appearance
- no excessive sharpening
- no excessive beauty retouching
- no unnatural perfection

---

# 18. Invocation Examples

### Example 1

用户： “调用 REALITY PHOTO ENGINE，把这张人物图真人化。”

执行： Human Portrait Mode + Reality Level 05.

### Example 2

用户： “把这只猫变成真实野生动物摄影。”

执行： Animal / Wildlife Mode + Reality Level 05.

### Example 3

用户： “保持这辆车设计不变，变成真实汽车广告摄影。”

执行： Automotive Photography Mode + Vehicle Identity Lock + Reality Level 05.

### Example 4

用户： “把这个外星人变成真实电影实拍效果。”

执行： Live-action Creature Mode + Environmental Interaction + Reality Level 05.

### Example 5

用户： “保留原图构图，只降低 AI 感。”

执行： Composition Lock + Identity Lock + AI Artifact Removal，避免改变主体设计。

---

# 19. 默认调用模板

当用户说：

“调用 REALITY PHOTO ENGINE”

自动理解为：

```text
REFERENCE IMAGE → REAL PHOTOGRAPHY
Reality Level: 05
Preserve Subject Identity: ON
Preserve Composition: ON
Preserve Key Visual DNA: ON
Material Realism: ON
Lighting Realism: ON
Camera Realism: ON
Environmental Interaction: ON
AI Artifact Removal: ON
```

除非用户明确要求，否则不要擅自改变主体设计、身份、比例或构图。