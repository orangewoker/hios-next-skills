---

## name: 短剧全流程系统 description: 短剧工业化创作系统。Use when creating, continuing, rewriting, inspecting, or validating a micro-short-drama project; triggers include /创意, /开始, /创作方案, /角色开发, /物品档案, /场景档案, /资产提示词 all, /目录, /分集 {N}, 生成第N集, 继续, 下一集, 分镜, 即梦, Seedance, or project markers .user-profile.json, .emotion-coupling-map.json, 分集目录.md, 角色档案.md.

# 短剧全流程系统

## 硬约束

1. **一次一个命令，文件间必停等**。创作期（/创作方案 等）每个文件落盘后停、等用户确认再推进。`/分集 {N}` 按混合确认模式推进——Phase 0→1 连续、剧本落盘后停；Phase 1.5→2 S1A 连续、首段分镜落盘后停；S1B\~S1H 每段必停。
2. **产物必须落盘文件**。所有生成内容写入文件，不只在对话中输出。
3. **每次落盘后跑校验**。被阻断则修复后重跑——校验脚本是规则的唯一可执行权威。
4. **零铺垫·冲突先行**（v2.0）：全集全段禁止场景空镜/角色定位/因果前置三类铺垫。从冲突中间切入，15s 只做一件事。
5. **信息融入冲突**：所有背景信息在冲突进程中自然释放，无独立交代段。
6. **视觉丰富**：每段 15s 必须满足运镜 ≥ 2 种 / 景别 ≥ 3 档 / 角度 ≥ 2 种 / 构图 ≥ 2 种。具体策略取值以 `pipeline.md` §0.3 分镜决策锁定表为准——不可从训练数据采样构图/运镜/角度替代锁定表取值。

## 项目判定

当前目录出现任一文件即判为微短剧项目：`.user-profile.json` / `.emotion-coupling-map.json` / `分集目录.md` + `角色档案.md`。

## 命令路由

用户输入控制器产物`/创意creative.md`无固定文件`/开始creative.md` → `scripts/init_project.py.user-profile.json/创作方案creative.md创作方案.md/角色开发creative.md角色档案.md/物品档案creative.md物品档案.md/场景档案creative.md场景档案.md/资产提示词 allcreative.mdAI 资产提示词/*.md/目录creative.md分集目录.md` 等`/分集 {N}pipeline.md`剧本 + 分镜提示词

极简输入如"5集"在项目目录内按 `/分集 5` 处理。

## 权威来源

范围权威命令链 + 前置 + 产物校验`scripts/_prerequisites.py` COMMAND_CHAIN`/分集 {N}` 状态机`scripts/pipeline_orchestrator.py`Phase 校验 + 阻断`scripts/verify_phase.py`AI 痕迹扫描`scripts/scan_ai_traces.py`分镜数据 JSON Schema（v4.0）`scripts/_storyboard_schema.py`（AI 产出结构化数据时的字段定义）分镜格式模板（v4.0）`templates/storyboard.md.j2`（Jinja2 纯模板，零规则，AI 不接触）分镜渲染脚本（v4.0）`scripts/render_storyboard.py`（JSON + 模板 → 落盘 Markdown）资产数据 JSON Schema（v4.0）`scripts/_asset_schema.py`（角色/物品/场景 JSON 字段定义）资产格式模板（v4.0）`templates/asset_*.md.j2`（Jinja2 纯模板，角色/物品/场景各一个）资产渲染脚本（v4.0）`scripts/render_assets.py`（JSON + 类型 → 落盘 Markdown）references 路由`references/_routing.yaml`（单源真理）沙盒门控`references/gates/沙盒门控规范.md`**创作决策锁定表**（v3.6）`creative.md` §0.1、§0.2（创意阶段判断唯一定稿）**分镜决策锁定表**（v3.6）`pipeline.md` §0.3（导演判断唯一定稿）

文档与脚本冲突时以脚本输出为准。控制器文件不复述、不翻译脚本已经编码的规则。

## 执行规范速查

- **沙盒门控**：创作期每个文件执行 5 步循环（读→写→checkpoint→摘要→等用户），详见 `references/gates/沙盒门控规范.md`。
- **零弹窗**：禁止 `rm -rf` / `Remove-Item -Recurse -Force` 等黑名单命令；文件操作统一用 `scripts/_file_ops.py`。禁止创建 `tmp_` / `.tmp` 前缀临时文件；决策点用 `--decision-points-stdin` 管道传参。
- **资产边界**：角色/物品/场景档案保持数据纯净——角色档案不含场景和独立调度物，物品档案不含角色和场景，场景档案不含角色和独立调度物。一图一资产。
- **不调用外部 Skill**：生成剧本、资产、分镜只用本 Skill 的脚本和 references。
