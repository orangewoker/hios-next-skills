# Cinematic Storyboard Video Production

## Core Methodology

### Storyboard Decomposition Framework

Break long-form narrative scripts into sequential segments using dramatic arc logic:

**Temporal Segmentation Dimensions:**

- **Scene Continuity**: Each segment = one complete dramatic beat with clear entry/exit states
- **Duration Constraint**: Each segment ≤15s to match video generation model limits
- **Narrative Hook**: Every segment ends with visual/emotional momentum that bridges to next segment

**Segment Anatomy (5-layer structure):**

1. **Continuity Header**: Precise description of character position, environment state, emotional status at segment start (inherited from previous segment's exit state)
2. **Shot Breakdown**: Each segment contains 2-4 shots with:
   - Shot number + timestamp range
   - Frame size (ECU/CU/MCU/MS/WS/ELS)
   - Camera movement (fixed/push/pull/pan/tilt/handheld)
   - Visual composition (foreground/midground/background elements, lighting, color)
   - Dialogue (if any, with character attribution)
   - Sound design (ambient/foley/score cues)
3. **Dramatic Action**: The core visual event of this segment
4. **Exit Hook**: The unresolved visual/emotional element that propels into next segment
5. **Technical Metadata**: Duration, node identifier

### Multi-Stage Production Workflow

**Stage 1: Script Analysis & Segmentation**

- Read complete script chronologically
- Identify dramatic beats (setup → conflict → climax → resolution)
- Mark natural pause points (scene changes, emotional shifts, action peaks)
- Calculate segment count: total_duration / 12s (average segment length with buffer)
- Create segment table with: ID | Duration | Script Range | Core Action | Exit Hook

**Stage 2: Detailed Storyboard Generation**

For each segment sequentially:

1. **Continuity Check**: Review previous segment's final frame state
2. **Shot Design**: Design 2-4 shots covering:
   - Wide establishing shot (if scene change)
   - Medium shots for character action
   - Close-ups for emotional beats
   - Insert shots for key props/details
3. **Transition Logic**: Ensure visual flow between shots (match-on-action, eyeline match, 180° rule)
4. **Prompt Construction**: Write shot descriptions in present tense, active voice, with concrete visual details

**Stage 3: Node Creation & Documentation**

*Parallel text node creation:*

- Create one text node per segment
- Node title format: "S{segment_number:02d} | {duration}s | {core_action_summary}"
- Node content = full storyboard text (continuity + all shots + metadata)
- Batch process 5 segments at a time to maintain API stability

**Stage 4: Video Generation**

*Critical prompt extraction rule:*

- **NEVER summarize or paraphrase** storyboard content when creating video nodes
- Video prompt = exact full text from storyboard segment (all shots, all descriptions, all technical notes)
- Rationale: Storyboard text already optimized for model interpretation; any compression loses critical visual details

*Batch generation strategy:*

- Process 5 video nodes in parallel per batch
- Wait for batch completion before next batch (prevents rate limiting)
- Link each video node to corresponding text node via metadata

**Stage 5: Quality Assurance**

- Cross-check video node count matches segment count
- Verify each video prompt contains full storyboard text (not truncated)
- Validate continuity: each segment's starting state matches previous segment's ending state

## Workflow

### 1. Preparation Stage

**Input Requirements:**

- Complete narrative script with scene descriptions, dialogue, emotional beats
- Target total duration (if specified)
- Canvas/project context for node creation

**Pre-Production Checklist:**

- Identify script language (Chinese/English/Japanese) for consistent output
- Count total scenes and estimate segment breakdown
- Mark critical dramatic moments requiring close-ups
- Note any recurring visual motifs or props

### 2. Storyboard Generation Stage

**Execution Approach:**

*Step 1: Create master segment table*

```
| Segment | Duration | Script Range | Core Action | Exit Hook |
|---------|----------|--------------|-------------|----------|
| S01 | 10s | Line 1-8 | Character enters environment | Hand picks up object |
| S02 | 12s | Line 9-15 | Object ignites | Fire reflected in eyes |
...
```

*Step 2: Generate detailed storyboard for each segment*

For S01 example:

```
## S01 | 10s | Character Enters Environment

**Continuity:** (none, opening shot)

**Shot 01 | 0.0s–3.0s | ECU → MS**
- Camera: Fixed, focus pull from foreground to midground
- Visual: Foreground = [prop details], background = [environment description]
- Sound: [ambient sound]

**Shot 02 | 3.0s–6.5s | CU**
- Camera: Fixed, low angle, tilt up
- Visual: [hand action, skin texture, lighting]
- Sound: [foley detail]

**Shot 03 | 6.5s–10.0s | CU**
- Camera: Fixed
- Visual: [object interaction closeup]
- Sound: [silence/wind]

**Exit Hook:** Hand gripping object, preparing next action
```

*Step 3: Apply continuity inheritance*

S02's continuity header = S01's exit hook description:

```
**Continuity:** Character crouching in corner, right hand gripping red lighter, body shivering, bridge underpass background
```

### 3. Node Creation Stage

**Text Node Creation:**

Batch process (5 segments per batch):

```python
for segment in segments[batch_start:batch_end]:
    create_text_node(
        title=f"{segment.id} | {segment.duration}s | {segment.summary}",
        content=segment.full_storyboard_text,  # Complete, unabridged
        metadata={"segment_id": segment.id, "type": "storyboard"}
    )
```

**Video Node Creation:**

Critical rule: `video_prompt = text_node.content` (NO summarization)

Batch process (5 segments per batch):

```python
for segment in segments[batch_start:batch_end]:
    create_video_node(
        prompt=segment.full_storyboard_text,  # Must be complete text
        duration=segment.duration,
        metadata={"segment_id": segment.id, "text_node_ref": segment.text_node_id}
    )
```

### 4. Iteration & Correction Stage

**Quality Check Dimensions:**

1. **Completeness Audit:**

   - Count: `video_node_count == segment_count`
   - Content: Each video prompt contains full storyboard (not truncated summary)
   - Metadata: Each video node links to corresponding text node

2. **Continuity Audit:**

   - Review segment pairs: S{N} exit state → S{N+1} entry state
   - Check for orphaned segments (missing continuity link)

3. **Prompt Fidelity Audit:**

   - Sample 3 random video nodes
   - Compare video prompt to source storyboard text
   - If ANY mismatch found → regenerate ALL video nodes with strict prompt rule

**Regeneration Protocol (when prompt fidelity fails):**

1. Mark all existing video nodes as deprecated
2. Re-read full storyboard master file
3. Regenerate video nodes in batches with explicit rule:

   ```
   video_prompt = storyboard_segment.raw_text  # No processing, no summarization
   ```
4. Update segment tracking table with new node IDs

## Key Constraints & Standards

### Immutable Rules

1. **Segment Duration Limit**: Each segment ≤15s (hard constraint from video generation model)
2. **Prompt Fidelity**: Video node prompt MUST be character-exact copy of storyboard text
3. **Language Consistency**: All output (storyboard + prompts + metadata) in same language as input script
4. **Sequential Dependency**: S{N+1} cannot be designed until S{N} storyboard is finalized

### Continuity Standards

1. **Visual Continuity**: Character position, costume state, prop placement, lighting direction must be explicitly carried forward
2. **Temporal Continuity**: If S01 ends with "hand approaching fire", S02 MUST start with "hand hovering over fire" (not "hand withdrawn")
3. **Emotional Continuity**: Character expression/body language at segment end = segment start of next

### Storyboard Quality Standards

1. **Shot Completeness**: Every shot must specify:

   - Frame size (required)
   - Camera movement (required)
   - Visual composition with concrete nouns (required)
   - Sound design (required)
   - Dialogue if applicable

2. **Description Concreteness**:

   - BAD: "Character looks sad"
   - GOOD: "Character's eyebrows furrow, mouth corners drop, eyes glisten with unshed tears"

3. **Technical Precision**:

   - Use standard film terminology (ECU/CU/MS/WS/ELS, not "very close/medium/far")
   - Specify camera position (low angle/high angle/eye level)
   - Note depth of field (foreground sharp, background bokeh)

### Batch Processing Standards

1. **Batch Size**: 5 nodes per parallel batch (prevents API rate limiting)
2. **Sequential Batches**: Wait for batch N completion before starting batch N+1
3. **Error Handling**: If any node in batch fails, retry entire batch (maintains sequence integrity)

## Recommended Tools & Models

Use Seedance 2.0 or equivalent video generation model supporting:

- 10-15s duration per generation
- Text-to-video with detailed prompt interpretation
- Cinematic camera movement simulation
- Shot composition control

## Example

**Input Script (excerpt):**

```
在桥洞的一个角落,几个带吸管的塑料瓶带着几张锡纸,陪伴着一个几乎没气的打火机。
李火旺伸出那几乎没有知觉的手,捡起那红色的透明打火机。
```

**Output Segment Storyboard:**

```
## S01 | 10s | 桥洞角落,麻木的手

**承接/连续性:** 无(开场)

**镜号 01 | 0.0s–3.0s | 极近景(ECU)→ 中景(MS)**
- 运镜: 固定,焦点从前景物件拉向中景人物
- 画面: 画面最前景是几个带吸管的塑料瓶,旁边散落锡纸,一个几乎没气的红色透明打火机躺在地上;背景虚焦中,桥洞阴暗的混凝土墙逐渐清晰,李火旺蜷缩在角落,衣物破旧潮湿,身形消瘦,面色灰白。
- 音效: 远处桥上偶有车声,风从洞口灌入的低鸣

**镜号 02 | 3.0s–6.5s | 近景(CU)**
- 运镜: 固定,低机位,仰拍手部
- 画面: 李火旺缓缓伸出右手,手指皮肤龟裂泛紫,指节几乎失去知觉地颤抖;手指触碰到红色透明打火机的瞬间,停顿半拍。
- 音效: 塑料轻微摩擦地面的细碎声

**镜号 03 | 6.5s–10.0s | 近景(CU)**
- 运镜: 固定
- 画面: 李火旺的手缓慢包裹住打火机,将它捡起;画面右侧是打火机的红色透明机身,左侧是他龟裂的手指;他将打火机握在掌心,拳头微微收紧。
- 音效: 无,只余风声
```

**Video Node Prompt (MUST be identical to above storyboard text):**

```
## S01 | 10s | 桥洞角落,麻木的手

**承接/连续性:** 无(开场)

**镜号 01 | 0.0s–3.0s | 极近景(ECU)→ 中景(MS)**
...(full text, no truncation)
```

## Advanced Techniques

### Dynamic Segment Duration Allocation

For scripts with uneven pacing, use variable segment durations:

- **Action sequences**: 8-10s per segment (fast cutting)
- **Emotional beats**: 12-15s per segment (hold on reactions)
- **Establishing shots**: 10-12s per segment (environment absorption)

Adjust segment boundaries to align with natural dramatic peaks rather than rigid time intervals.

### Cross-Segment Motif Tracking

For recurring visual elements (e.g., a red lighter appearing in S01, S03, S09):

1. Create a "motif register" during script analysis
2. Standardize description language for each motif occurrence
3. Ensure lighting, angle, and framing consistency across segments

Example motif entry:

```
Red Lighter:
- Color: translucent red plastic, slightly faded
- Size: standard disposable lighter (7cm length)
- Condition: low fuel, striker wheel worn
- Lighting: always backlit or side-lit to show translucency
```

### Parallel Generation Optimization

For large projects (20+ segments), use tiered parallel processing:

- **Tier 1**: Generate text nodes for ALL segments first (faster, no rate limits)
- **Tier 2**: Generate video nodes in 3-batch waves (15 nodes across 3 parallel batches)
- **Tier 3**: Continuity QA pass after each wave before proceeding

This approach catches continuity errors earlier while maintaining generation speed.