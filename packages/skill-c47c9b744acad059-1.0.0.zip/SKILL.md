---
{
  "name": "skill-c47c9b744acad059",
  "description": "昆汀塔伦蒂诺：能够生成昆汀风格的图片skill",
  "metadata": {
    "title": "昆汀塔伦蒂诺",
    "category": "其他",
    "version": "1.0.0",
    "originalFile": "skill/昆汀塔伦蒂诺.md",
    "author": "微信用户d513cd",
    "upstreamVersion": "1.0.1",
    "source": "https://www.liblib.tv/skill"
  }
}
---

---

## name: kunting description: 将用户的简单画面描述转化为复古犯罪类型片、黑色幽默、潜在威胁、鲜明人物关系和模拟胶片色彩的电影级图片提示词。适用于用户要求犯罪类型片导演化、复古胶片、对话悬念、人物对峙、特殊主观机位或强烈叙事电影画面时；不用于视频提示词、普通事实问答、代码任务或用户明确要求其他视觉体系时。

# 电影犯罪类型图片提示词

把用户创意视为不可替换的核心。默认风格强度为 `2`；`1` 使用一种观看逻辑，`2` 使用两种，`3` 可组合空间嵌入、物件凝视和镜头滞留，但不得靠堆叠剧情或复刻现有作品获得风格。

## 工作流

 1. 读取 constraint-priority.md，提取主体、人物数量、人物参考、族裔、地域、地点、时间、动作、朝向、人物关系、视线、画幅和硬性约束；先建立一级约束锁，缺失信息只做最小补足。
 2. 判断类型：对话、等待、登场、对峙、驾驶、追逐、冲突前、冲突中、冲突后或无人环境。
 3. 保留主体、时代、地域、身份、动作和画幅；把场所年代与故事年代分开，未指定时代时保持当代或时代中立，不把“类型感”变成固定历史或外国布景。
 4. 读取 viewing-logic.md，依据强度选择空间嵌入、物件凝视或镜头滞留。先写摄影机在场景内部的物理位置，再明确语义主体、视觉锚点和环境的非均衡权重。
 5. 把静态画面定义为长时间固定观察中的一帧，或明确为何必须截取过渡瞬间；不要默认把所有动作戏剧化。特殊机位必须明确物理位置、边框占比、人物占比和遮挡上限。
 6. 只有场景确实需要时才添加至多一个潜在矛盾或反差；它不得改变一级约束，也不得代替观看逻辑。无法找到兼容矛盾时不添加。
 7. 每次读取 signature-color-response.md，默认采用中高色彩密度、饱满中间调与浓而有染料偏色的黑位；复古不等于低饱和。用户提供参考图、原图或失败输出时，再读取 reference-color-transfer.md，按顶部、中部、底部及语义区域建立空间转译卡；保留参考的亮度拓扑、色块面积和颜色落点。随后读取 light-color-architecture.md，完成主光、覆盖区、禁光区、背景相对曝光和色块布置。
 8. 有人物时读取 casting-defaults.md 与 character-system.md。人物参考、族裔和地域优先；全部缺失时才使用原创欧美人物默认池，不复制参考演员或现有角色。
 9. 添加姿态、目光、材质和选择性使用痕迹；动作可处于过渡、重复、等待或结束后的滞留状态，避免海报式标准姿势。
10. 读取 film-response.md，以 35mm 负片—印片响应约束色彩密度、肤色、黑位、颗粒、高光光化与有限锐度；胶片不等于年代设定，避免流媒体犯罪剧式欠曝、褐色滤镜和精致数字感。
11. 对新增动作、目光、矛盾和道具执行冲突检查；在负面约束中排除硬约束的反义失败，完成 output-calibration.md 后再输出。

## 渐进式读取

- 每次读取 constraint-priority.md、viewing-logic.md、prompt-template.md、negative-constraints.md 和 output-calibration.md。
- 摄影或特殊机位读取 visual-language.md 与 composition-system.md。
- 色彩与曝光每次读取 signature-color-response.md、light-color-architecture.md、color-system.md、lighting-system.md 与 film-response.md。
- 有参考图、原图或生成反馈时额外读取 reference-color-transfer.md，参考驱动的空间亮度与色块关系优先于常规曝光范围。
- 有人物时读取 casting-defaults.md 与 character-system.md；需要悬念、冲突或黑色幽默时读取 narrative-system.md。
- 需要判断证据边界时读取 source-methodology.md。

## 输出

只输出以下两段，不展示内部分析、校准评分或规则命中：

```text
【正向提示词】

一段自然、连续、具体、可直接复制的中文图片提示词。

【负面约束】

一段针对当前场景的中文约束。
```

不得提及具体导演、影片、现有角色或使用作者姓名式风格捷径；不得复制标志性服装、对白、布景或镜头；不得强行加入枪械、香烟、血迹、餐馆、黑西装、霓虹夜景或单一黄色调。

## 随附资料
原附件保存在 attachments/ 目录；正文引用的相对资源请从该目录读取。
