---
{
  "name": "skill-c394b74401965ab4",
  "description": "文旅海报动态视频生成器：素材图一键生成文旅海报与动态视频",
  "metadata": {
    "title": "文旅海报动态视频生成器",
    "category": "影视分镜",
    "version": "1.0.0",
    "originalFile": "skill/文旅海报动态视频生成器.md",
    "author": "星美Fine",
    "upstreamVersion": "1.0.11",
    "source": "https://www.liblib.tv/skill"
  }
}
---

# 文旅海报 × 动态视频生成器

## 一、Skill 定位

将建筑图、风景图、室内图等文旅素材，一键转化为具有杂志大片感、印刷质感、艺术排版的文旅宣传海报，再将所有海报合成九宫格静态拼图，最后基于**已生成的海报图片**生成动态宣传视频。

**适用场景：** 文旅宣传、朋友圈、自媒体发布、线下物料制作

**完整链路（不可乱序）：**

```
素材图输入 → 文案生成 → 排版风格选择 → 海报生成 → 用户确认
→ 九宫格拼图生成 → 用户确认 → 动态视频生成（输入为已生成海报）→ 交付
```

---

## 二、核心设计理念

> 所有生成决策的哲学基础。每一步操作都必须以此为准绳，不可绕过。

**文旅海报卖的不是物品，而是一段想象和一种体验。好的文旅海报要能在3秒内让人产生「我想去」的冲动。**

### 🎨 视觉层面：一张图讲一个故事

- **叙事感主图**：优先选择能体现人与环境互动、有故事感的画面，而非单纯空景。若素材为空景，必须通过构图和文案弥补叙事感。
- **留白与呼吸感**：画面不塞满。构图优先使用三分法、对称构图或引导线构图，让视线自然聚焦核心内容。
- **色彩传递情绪**：暖色调→烟火气/美食；冷色调→自然山水静谧；高饱和→节庆/民俗活动。色调必须与目的地氛围一致。

### 📝 文字层面：少即是多

- **主标题**：整张海报的灵魂。**严禁**「XX欢迎您」「美丽XX」等空洞表述。必须有记忆点，如「去有风的地方」「黔灵山翻红」。
- **副标题**：一句话补充时间/地点/活动亮点。
- **排版层次**：主标题最大→副标题次之→辅助信息最小。字体不超过两种。字体大小必须形成强对比，排版方式根据素材和风格智能适配（见七、使用约束）。

### 🔑 策略层面：从「看见」到「想去」

- **提炼 USP（独特卖点）**：这个地方有什么是别处没有的？所有视觉和文字元素都必须围绕这个核心卖点展开。
- **精准定位目标人群**（影响风格选择和文案语气）：
  - **年轻人**：强调打卡、潮流、沉浸式体验 → 现代撞色/波普风格
  - **亲子家庭**：突出互动性、安全性、寓教于乐 → 温暖亲切风格
  - **文化爱好者**：强调历史底蕴、非遗体验 → 复古水墨/极简高级风格

### 💡 加分技巧

- **系列化设计**：每张突出一个亮点（美食篇/风景篇/文化篇），形成组合传播效应——这也是本 Skill 九宫格设计的核心价值。
- **多平台尺寸**：竖版3:4（朋友圈/抖音）、方版1:1（九宫格）、横版16:9（线下物料）同步考虑。

---

## 三、黄金比例排版规范

> 排版的数学基础。生成每张海报时，构图和排版决策必须遵循以下规则，不可凭感觉随意布局。

**核心数值：** 黄金比例 = 1:1.618（φ ≈ 0.618）。实用近似值：3:5≈0.6、5:8≈0.625、三分法是其简化版。

### 五大实战规则

规则内容Prompt 关键词**R1 版面分割**主图占62%，文字区占38%；上下/左右均适用；**严禁对半切（50:50）**`golden ratio composition, 62:38 layout split`**R2 字号层级**主标题→副标题约1.8\~2倍（如45pt→23pt）；副标题→辅助信息约1.5\~1.618倍`typographic hierarchy with 1.8x scale ratio, headline 2x subtitle`**R3 行间距**正文行高 = 字号 × 1.5\~1.618，段落间距同比例`line height 1.618x font size, generous paragraph spacing`**R4 视觉焦点**主体元素置于黄金分割点（画面38.2%或61.8%处），而非正中间；眯眼检验：两侧视觉重量不等才对`subject at golden focal point, off-center dynamic balance`**R5 图文比例**图片面积:文字区域 ≈ 6:4，适用于所有分栏类风格（L-01/L-03/L-08）`image to text ratio 6:4, balanced composition`

### 80/20 视觉权重法则

- **主角**（大标题+主体图+核心信息）占约 **80%** 视觉权重
- **配角**（小字说明+装饰元素+背景纹理）控制在 **20%** 以内
- Prompt 关键词：`80/20 visual weight distribution, hero element dominates, supporting elements minimal`

---

## 四、设计语言知识库

> 来源于27张文旅海报参考图的设计规律提炼。生成每张海报时，必须从以下三个库中各选取对应项写入 prompt。

### 4.1 色块叠加类型库（12种）

编号名称颜色/形态透明度适用场景Prompt 关键词CB-01深色渐变蒙版黑/深灰，底部向上渐变底60%→顶0%全图封面，保证文字可读性`dark gradient overlay from bottom, opacity 60% to 0%`CB-02撞色几何色块橙+蓝/红+黑/黄+紫，矩形或不规则几何100%现代城市建筑，大字冲击风格`bold geometric color block collision, high contrast, 100% opacity`CB-03水墨晕染色块墨黑/深蓝/赭石，不规则晕染边缘70\~85%古建筑，传统文化，复古水墨`ink wash color splash, irregular edges, 75% opacity`CB-04荧光色点缀块荧光黄/绿/橙，小面积矩形或斜线条100%年轻化文旅，波普风，现代城市`fluorescent accent stripe, small geometric highlight`CB-05金色异形框金色/香槟金，不规则多边形边框100%东方雅致，高端文旅，古典建筑`gold irregular frame decoration, metallic border`CB-06渐变色块叠图橙→黄/蓝→紫/绿→青，大面积半透明叠加40\~60%现代城市，自然风景，梦幻氛围`gradient color wash overlay, 50% opacity, dreamlike atmosphere`CB-07笔刷色块紫/橙红/薄荷绿，手绘笔刷形态85\~100%漫画风，插画风，艺术感文旅`brushstroke color block, hand-painted edge`CB-08波浪色块蓝黄撞色/红白，波浪形曲线分割100%古建筑系列，传统文化，增加动感`wave-shaped color divider, dynamic curve`CB-09圆形色块红/橙/金，正圆或椭圆，局部压图或文字底板100%城市地标，中英文混排，品牌感`circular color block as text background, bold red/gold`CB-10斜切拼贴色块金色底+多图斜切，撕纸效果边缘100%多图系列海报，品牌宣传册`diagonal cut collage, torn paper edge effect, gold base`CB-11超大字透明叠加与背景同色系，超大字号半透明叠加15\~30%现代城市，文字既装饰又信息`oversized semi-transparent text as decorative layer, 20% opacity`CB-12白色留白区域米白/纯白，上方大面积留白100%极简留白，高级感，精品文旅`large white/cream upper area, clean minimal space`

### 4.2 滤镜风格库（8种）

编号名称色调描述适用素材Prompt 关键词F-01冷灰蓝调降饱和，偏冷蓝灰，高对比，轻微暗角徽派/江南古建筑，雨雾山水`cool gray-blue tone, desaturated, high contrast, subtle vignette`F-02复古胶片偏黄绿，颗粒感明显，高光溢出城市街景，旅行记录，青岛/重庆`vintage film grain, warm yellow-green cast, overexposed highlights`F-03水墨黑白极低饱和，高对比，墨色质感古建筑剪影，传统文化`ink wash monochrome, high contrast black and white, ink texture`F-04暖金夕阳偏橙金，高饱和，温暖感强自然风景，夕阳，盛唐/西域`warm golden hour tone, high saturation, orange glow`F-05青绿江南偏青绿，清新，轻微雾感江南水乡，园林，自然山水`fresh cyan-green tone, soft mist, low contrast`F-06波普高饱和高饱和，色彩鲜艳，接近印刷色城市波普风，漫画风，年轻化文旅`pop art high saturation, vivid print colors, bold contrast`F-07深夜霓虹深色背景，霓虹色点缀，高对比城市夜景，现代商业，音乐节`dark background, neon color highlights, high contrast night mood`F-08印刷做旧偏黄褐，纸张纹理，轻微褪色古建筑，历史文化，复古报纸`aged print tone, warm sepia, paper grain texture, faded effect`

### 4.3 排版风格库（8种）

每种风格的构图规则已内置黄金比例应用，选用时直接按规则执行。

编号风格名称字体构图规则（黄金比例已内置）适合人群Prompt 关键词L-01极简留白细黑体+无衬线细体+等线体上方38%留白，图片占下方62%；主标题置于黄金分割点；底部极细分割线+地名年份（极小字）文化爱好者、高端文旅`minimalist layout, white space upper 38%, photo bottom 62%, ultra-wide letter-spacing headline`L-02大字冲击粗黑体/超黑体+无衬线体全图背景+深色渐变蒙版；主标题置于黄金分割点偏上（38%处），非正中；字号层级约2倍年轻人、社交媒体传播`oversized bold headline at golden focal point, dark gradient overlay, 2x font scale ratio`L-03全图封面衬线体+无衬线细体+细黑体图片铺满；文字区域占38%；左/右侧竖排主标题置于62%分割线处；底部细横线+地名（极小字）文化爱好者、品牌宣传`magazine cover layout, full-bleed photo, text area 38%, vertical title at 62% line, serif typeface`L-04镂空字填充超大字号镂空字体镂空字体占80%视觉权重；背景纯色或渐变；副标题置于黄金分割点下方年轻人、打卡传播`giant hollow letterform filled with photo, 80% visual weight on letterform, solid background`L-05复古水墨毛笔体+印章字体+细黑体水墨背景；毛笔字置于黄金分割点偏右（61.8%处）；印章点缀在对角黄金点；竖向构图文化爱好者、中老年群体`ink wash calligraphy at golden focal point, seal stamp at diagonal golden point, vertical composition`L-06撞色现代粗黑体+无衬线体+等线体色块按62:38比例分割；主标题置于较大色块的黄金分割点；多语言混排年轻人、城市文旅`color-block collision layout, 62:38 split, headline at golden focal point of larger block, multilingual`L-07拼贴波普无衬线粗体+手写体+等线体多图网格或斜切拼贴；主标题占80%视觉权重；荧光色点缀控制在20%以内年轻人、系列化传播`collage grid layout, pop art style, 80% visual weight on headline and images, fluorescent accents under 20%`L-08拍立得相框手写签名体+细黑体+无衬线体相框内图片占62%，底部信息栏占38%；手写感强，温暖亲切亲子家庭、民宿/室内`polaroid frame, image 62% of frame, info bar 38% bottom, handwritten signature font`

---

## 五、风格与素材匹配规则

> 当用户未指定风格时，根据此表自动匹配。同时结合第六章 Step 1 判断的目标人群做最终决策。

素材类型推荐排版风格推荐色块推荐滤镜核心策略徽派/江南古建筑（白墙黛瓦、马头墙）L-01 / L-05CB-12 / CB-03F-01 / F-08意境与文化底蕴，克制优雅宫殿/故宫/皇家建筑L-02 / L-04CB-01 / CB-09（红）F-04 / F-08气势与历史感，红金配色现代城市地标/商业建筑L-02 / L-06CB-02 / CB-11F-06 / F-07现代感与活力，高对比撞色自然风景（山水、云雾、田野）L-01 / L-03CB-06 / CB-12F-05 / F-01自然美感，色调清新或冷峻室内空间（民宿、茶室、书院）L-08 / L-01CB-12 / CB-05F-04 / F-02温暖质感与生活美学古镇/街巷/市井L-07 / L-05CB-07 / CB-10F-02 / F-08烟火气与历史层次感海洋/滨海/港口L-03 / L-06CB-04 / CB-08F-05 / F-07开阔感与现代活力寺庙/宗教建筑L-05 / L-03CB-03 / CB-05F-08 / F-03庄严感与文化厚重感

---

## 六、完整工作流程

### 阶段一：海报生成

Step 1 — 接收素材与文案

接收用户输入：

- **素材图**：建筑图/风景图/室内图，数量不限（1张或多张）
- **文案模式**（二选一，若未说明则询问）：

**模式A — 手动输入：** 用户提供主标题、副标题、slogan、地点信息等。

**模式B — AI 自动生成：** 按以下四步规范执行：

1. **分析 USP**：这张图里有什么是别处没有的？（独特自然景观/建筑形态/文化符号/情绪氛围）把核心卖点作为文案出发点。

2. **判断目标人群**，调整文案语气：

   - 现代建筑/街头/夜景 → 年轻人 → 打卡/沉浸式体验，语气活泼
   - 古建筑/寺庙/非遗 → 文化爱好者 → 底蕴与情感共鸣，语气沉稳有力
   - 自然山水 → 通用/文化爱好者 → 静谧与逃离感，语气诗意留白
   - 亲子/民俗 → 亲子家庭 → 互动与温暖，语气亲切

3. **生成三层文案**：

   - 主标题（4\~10字）：有记忆点，**严禁**「XX欢迎您」「美丽XX」等空洞表述
   - 副标题（10\~20字）：补充时间/地点/活动亮点
   - 辅助信息（极小字）：**仅限**地点名称、英文地名/标签、年份；**严禁**出现二维码或任何 CTA 占位

---

Step 2 — 排版风格选择

展示第四章排版风格库（L-01\~L-08）供用户选择，可每张单独选或统一选一种。

若用户未指定，根据**第五章匹配规则** + **Step 1 判断的目标人群**自动匹配。

---

Step 3 — 海报生成（并行）

对每张素材图，按选定风格和文案**并行生成**海报。

**生成前必须通过以下检查清单（10项全部满足才可生成）：**

检查项标准① 主标题记忆点有具体意象或情绪，无空洞表述② 叙事感画面有故事感，或通过构图/文案弥补③ 色调一致性滤镜色调与目的地氛围匹配④ 底部信息合规底部仅有地名/英文标签/年份（极小字），**无二维码、无 CTA 占位**⑤ 版面分割接近62:38，非50:50⑥ 视觉焦点主标题/核心图像置于黄金分割点，非正中⑦ 字号强对比主标题→副标题→辅助信息三级字号差距明显，符合所选风格的层级规范⑧ 排版方式与风格匹配排版方式与素材内容和所选风格一致，**无等间距居中堆叠**（三行文字不在同一垂直轴上等间距排列）⑨ 视觉权重主角占约80%，配角控制在20%以内⑩ 文字块呼吸感各文字块之间有意留出不等量空白，制造视觉张力

**Prompt 六段式拼装结构（缺一不可）：**

```
[①主体描述] + [②排版风格关键词] + [③色块叠加关键词] + [④滤镜关键词] + [⑤质感+黄金比例+排版锚点] + [⑥尺寸比例]
```

**① 主体描述**（每次替换）：

```
Cultural tourism poster featuring [素材内容，如：Huizhou ancient architecture, white walls and black tiles, misty mountains]
```

**② 排版风格关键词**：从第四章4.3排版风格库对应编号的 Prompt 关键词列取用。

**③ 色块叠加关键词**：从第四章4.1色块叠加类型库选1\~2种，取对应 Prompt 关键词。

**④ 滤镜关键词**：从第四章4.2滤镜风格库选1种，取对应 Prompt 关键词。

**⑤ 质感 + 黄金比例 + 排版锚点**（固定写入，每张必须包含）：

```
magazine editorial quality, print texture, typographic design, high-end visual, Chinese-English bilingual layout, artistic composition, narrative visual storytelling, breathing space in composition, golden ratio composition (62:38 layout split), typographic hierarchy with 1.8x scale ratio, subject at golden focal point, off-center dynamic balance, 80/20 visual weight distribution, line height 1.618x font size, dramatic font size contrast HUGE-medium-tiny, intentional whitespace between text elements, no equidistant center-aligned text stacking, bottom text only location name and year in tiny font, no QR code no CTA
```

> **排版方式自适应说明**：交错偏移排版（Z形/阶梯文字流动）根据素材和风格智能适配，不强制所有海报使用。具体适配逻辑见「七、使用约束 — 【推荐】自适应排版规范」。

**⑥ 尺寸比例**：

- 默认竖版：`vertical format 3:4`（朋友圈/手机）
- 方图：`square format 1:1`（九宫格）
- 横版：`horizontal format 16:9`（线下物料）

每张素材图输出1张海报（如需同一张图出多个风格版本，在此步骤说明）。

---

Step 4 — 海报确认

展示所有生成的海报，询问用户：

- 是否满意？
- 是否需要调整某张的文案、风格、色块或滤镜？

> ✅ 用户确认所有海报后，才进入阶段二。**不可跳过此步骤。**

---

### 阶段二：九宫格拼图生成

> ⚠️ 此阶段必须在所有海报确认完成后执行。九宫格拼图是视频生成的唯一输入源，不可跳过。

Step 5 — 生成九宫格静态拼图

将所有已确认的**海报图片**（Step 3 生成的成品海报，非原始素材图）拼合成标准九宫格展示图。

**生成规则：**

- 布局：3×3，共9格
- 海报数量 = 9张：按视觉差异最大化原则排布
- 海报数量 &lt; 9张：重复使用，交错排列填满9格（如3张各重复3次）
- 海报数量 &gt; 9张：选取视觉最具代表性的9张
- 格间距：细白色间距线，约2\~3px
- 整体背景：深灰色或黑色
- 整体比例：正方形1:1

**输出：1张九宫格静态拼图（1:1方图）**

Step 6 — 九宫格拼图确认

展示九宫格拼图，询问用户是否满意排布效果。

> ✅ 用户确认后，才进入阶段三。

---

### 阶段三：动态视频生成

> ⚠️ **视频生成的输入必须是已生成的海报图片（Step 3 产出的成品海报），不是原始素材图，也不是九宫格拼图。** 这是本 Skill 经过实际验证的关键规范。

Step 7 — 视频模型与展示模式选择

依次询问用户两个选择：

**第一问 — 视频生成模型：**

- **SD2.5**（Stable Diffusion 2.5）：适合风格化、艺术感强的动态效果
- **MiniMax**：适合流畅自然的动态过渡和镜头感

**第二问 — 视频展示模式：**

- **模式A — 九宫格整体动效**：以九宫格拼图为输入，整体缓慢放大+各格依次点亮，适合朋友圈九宫格发布预览、品牌整体展示
- **模式B — 逐一海报动效**：9张海报依次全屏单独展示，每张停留约0.8秒，入场动效+文字元素动效多样化交替，适合抖音/小红书/朋友圈视频
- **两种都要**：分别生成模式A和模式B两条视频

---

Step 8 — 动态视频生成

根据 Step 7 用户选择的模式执行对应生成流程。

> **【内部执行规则，不对用户展示】**
>
> - 视频生成 Prompt 必须全部使用英文，不在 Prompt 中写入任何中文文字内容
> - Prompt 末尾必须加 `No text, no subtitles, no captions in the video. Pure visual motion design.`
> - 文字动效描述的是海报上**现有文字元素如何运动**（existing text elements animate），而非让模型生成新文字
> - 违反以上规则会导致视频中出现中文乱码，无法修复

---

【模式A — 九宫格整体动效视频】

**输入：** Step 5 生成的九宫格静态拼图

**生成参数：**

- 时长：5\~10秒（默认8秒）
- 动态效果：九宫格整体缓慢放大（Ken Burns）→ 各格依次点亮/浮现 → 轻微视差滚动 → 结尾定格
- 输出格式：MP4，竖版9:16或方版1:1
- 适用场景：朋友圈九宫格发布预览、品牌整体展示

**Prompt 模板：**

```
A dynamic cultural tourism promotional video, vertical 9:16, 8 seconds total.
Nine-grid layout of cultural tourism posters displayed as a whole composition.
Overall slow Ken Burns zoom from center outward, each grid cell lights up sequentially from top-left to bottom-right with subtle glow effect.
Gentle parallax scroll motion, final frame holds steady.
Visual style: high-end cultural tourism brand film, print texture, magazine editorial quality, rich saturated colors, cinematic feel.
No text, no subtitles, no captions in the video. Pure visual motion design.
```

---

【模式B — 逐一海报动效视频】

**输入：** 所有已确认的**成品海报图片**（Step 3 产出，最多取9张，优先选视觉差异最大的）

> ⚠️ 输入必须是成品海报，不是原始素材图。

**生成参数：**

- 每张海报停留时长：约0.8秒
- 总时长：约8秒（9张 × 0.8秒 + 过渡）
- 输出格式：MP4，竖版9:16
- 适用场景：抖音、小红书、朋友圈视频

**画面入场动效规则（9张各不相同，按以下顺序循环分配）：**

张序入场动效第1张缓慢放大（Ken Burns，从中心向外）第2张从左滑入第3张从下推入，带轻微淡入第4张轻柔溶解淡入第5张轻微旋转缩放弹入（90%→100%）第6张Ken Burns 从左下角扩展第7张从右滑入第8张从上推下第9张淡入后轻微缩放定格

**切换过渡：** 黑场闪切（干净利落，不用缓慢叠化）

**文字与元素动效规范：**

> 文字动效描述的是海报上**已有文字元素如何运动**，不是让模型生成新文字。Prompt 中描述「existing headline text animates」而非「show Chinese text」。

**文字动效类型库（按排版风格匹配）：**

排版风格主标题动效描述（英文）副标题动效装饰元素动效L-01 极简留白`existing headline text focus-pulls from blur to sharpexisting subtitle text types on character by characterthin dividing line draws from left to right`L-02 大字冲击`existing large headline characters fly in from left one by oneexisting subtitle text types oncolor block slides up from bottom`L-03 全图封面`existing vertical title characters rise up from bottom one by oneexisting subtitle text types ondecorative line extends from center outward both sides`L-04 镂空字填充`existing hollow letterform focus-pulls into clarityexisting subtitle text types onexisting caption text floats up with fade`L-05 复古水墨`existing calligraphy characters drop down from top one by oneexisting subtitle text types onexisting seal stamp element rotates and scales in`L-06 撞色现代`existing headline block slides in from one side as a wholeexisting subtitle text types oncolor block slides up from bottom`L-07 拼贴波普`existing headline characters fly in from left one by oneexisting subtitle text types oncolor block slides up, existing caption floats up`L-08 拍立得相框`existing headline text fades in very slowlyexisting subtitle text types onthin line draws from left, existing caption floats up`夜景/霓虹（F-07）`existing headline text glows and fades in from transparentexisting subtitle text types onexisting caption text floats up with fade`

**Prompt 模板（模式B完整版）：**

```
A dynamic cultural tourism promotional video, vertical 9:16, 8 seconds total.
9 poster images displayed one by one full screen, each lasting about 0.8 seconds.

Each poster has unique entrance animation:
Clip 1 - slow Ken Burns zoom from center outward
Clip 2 - horizontal slide in from left
Clip 3 - push up from bottom with soft fade
Clip 4 - gentle dissolve fade in
Clip 5 - slight rotation zoom bounce in from 90% to 100%
Clip 6 - Ken Burns expand from bottom-left corner
Clip 7 - horizontal slide in from right
Clip 8 - push down from top
Clip 9 - fade in then slight zoom hold

Within each clip, existing text elements on the poster animate:
existing headline text animates with style-matched motion (fly-in, focus-pull, rise-up, or glow-fade depending on poster style),
existing subtitle text types on character by character,
existing decorative lines draw out, existing caption text floats up gently.

Transitions: black flash cut between each clip, clean and sharp.

Visual style: high-end cultural tourism brand film, print texture, magazine editorial quality,
rich saturated colors, cinematic feel, suitable for social media short video platforms.
No text, no subtitles, no captions in the video. Pure visual motion design.
```

---

Step 9 — 交付与后续建议

输出最终动态宣传视频（若选择「两种都要」则输出两条），并提示：

**发布建议：**

- 模式A（九宫格）：适合朋友圈九宫格发布、品牌整体展示
- 模式B（逐一展示）：适合抖音、小红书、朋友圈视频号，单张海报视觉冲击力更强
- 如需调整动效或时长，重新指定参数后再次生成

**系列化建议：**

- 当前多张海报已形成系列组合，建议分批次发布（美食篇/风景篇/文化篇），形成组合传播效应
- 分别导出竖版（朋友圈/抖音）、方版（九宫格）、横版（线下物料）三种尺寸

**素材归档：**

- 所有海报素材同步保存，可单独导出用于线下物料

---

## 七、使用约束

- **不适用场景**：纯文字海报（无图片素材）、非文旅类商业广告（如电商促销）
- **素材要求**：分辨率建议不低于1080p
- **流程约束**：视频生成输入必须是 Step 3 产出的**成品海报图片**，不是原始素材图；九宫格拼图仅用于模式A；两者不可混用
- **模型约束**：若所选视频生成模型不可用，提示用户切换另一个
- **文案约束**：AI 自动生成的主标题必须有记忆点，严禁输出「XX欢迎您」「美丽XX」等空洞表述；若图片信息不足，主动询问用户补充地点/主题信息
- **效果约束**：每张海报色块叠加不超过2种、滤镜不超过1种，避免效果堆砌
- **排版约束**：版面分割必须遵循黄金比例（62:38），严禁对半切（50:50）
- **【强制】禁止二维码**：海报底部严禁出现二维码或任何 CTA 占位文字。底部区域只允许保留：地点名称、英文地名/标签、年份，且必须使用极小字号。违反此规则的海报必须重新生成。
- **【推荐】自适应排版规范**：字体交错排列不是强制要求，根据素材内容和选定排版风格智能适配：
  - **叙事感强的素材**（寺庙、古建筑、夜景、人文场景）→ **推荐**交错偏移排版：三级字号强对比（超大→中→极小）+ Z形/阶梯文字流动；Prompt 追加：`staggered asymmetric text layout, Z-pattern visual flow, offset text blocks, typographic rhythm`
  - **极简留白（L-01）、拍立得相框（L-08）** → **推荐**对称克制排版，字号对比适中，不强制交错
  - **大字冲击（L-02）** → 主标题居中或偏置均可，副标题可交错偏移
  - **复古水墨（L-05）** → 竖排为主，交错体现在横竖混排的位置错落上
  - **撞色现代（L-06）、拼贴波普（L-07）** → **强烈推荐**交错偏移，增强现代感；Prompt 追加：`staggered asymmetric text layout, offset text blocks, dynamic typographic rhythm`
  - **总原则**：排版服务于素材和风格，不为交错而交错；但**任何情况下都严禁三行文字在同一垂直轴上等间距堆叠**