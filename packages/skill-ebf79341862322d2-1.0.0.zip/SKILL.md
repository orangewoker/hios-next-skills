---
{
  "name": "skill-ebf79341862322d2",
  "description": "小红书封面图生成：参考图一键生成小红书封面",
  "metadata": {
    "title": "小红书封面图生成",
    "category": "其他",
    "version": "1.0.0",
    "originalFile": "skill/小红书封面图生成.md",
    "author": "千寻AI部落",
    "upstreamVersion": "1.0.3",
    "source": "https://www.liblib.tv/skill"
  }
}
---

# 小红书封面图生成

## 目标

根据用户提供的参考图，生成一张 3:4 比例的小红书封面图，并在画面顶部添加用户指定的标题大字。

## 第一步：询问封面大字

在开始生成之前，先向用户提问：

> "请问封面上需要添加什么标题大字？"

等待用户回答后再继续。

## 第二步：生成人物主体图

以用户提供的参考图为输入，生成一张干净的人物主体图：

- 保留参考图中的人物形象、动作姿态与整体构图风格
- 背景风格：以参考图的背景元素为基础，适当调整为适合小红书风格的背景（明亮、清新、有质感，避免过于昏暗或杂乱）
- 画面比例：3:4
- 提示词附加：best quality, ultra detailed

## 第三步：生成定版封面

以第二步的人物主体图为画面基础，在画面顶部添加用户指定的标题大字：

- 文字排版：黄色与白色混合排布（部分字用黄色、部分字用白色）
- 风格关键词：cover design, bold title text, mixed yellow and white typography, best quality, ultra detailed
- 输出比例：3:4

## 输出

最终输出一张带标题大字的 3:4 小红书封面定版图。