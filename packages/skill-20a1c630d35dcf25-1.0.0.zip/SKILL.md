---
{
  "name": "skill-20a1c630d35dcf25",
  "description": "GL双女主｜欧美悬殊权力短剧漫剧生成器：欧美双女主悬殊权力短剧漫剧生成器，角色稳、卡点狠、能量产。",
  "metadata": {
    "title": "GL双女主｜欧美悬殊权力短剧漫剧生成器",
    "category": "影视分镜",
    "version": "1.0.0",
    "originalFile": "skill/GL双女主｜欧美悬殊权力短剧漫剧生成器.md",
    "author": "杭州金包银批发总部",
    "upstreamVersion": "1.0.2",
    "source": "https://www.liblib.tv/skill"
  }
}
---

# [SKILL.md](http://SKILL.md) | GL双女主｜欧美悬殊权力短剧漫剧生成器

## 【全局Skill调用路由表（底层识别）】

在开始任何操作前，必须强制调用以下父级/元认知Skill，必须严格使用英文slugID：

1.【影视制作Agent】（总调度）\
英文slugID：libtv-user-generated/industrial-film-production-director-074be3667ece41bc8993cea11c99240e\
对应显示名：影视制作Agent | 自动串联调度下层Skill

2.【顶级总制片人】\
英文slugID：libtv-user-generated/master-producer-quality-optimizer-074be3667ece41bc8993cea11c99240e\
对应显示名：顶级总制片人 | 第一性原理·元认知前置，是终结算力黑洞的唯一真相

3.【葵花宝典】\
英文slugID：libtv-user-generated/award-winning-script-analyzer-074be3667ece41bc8993cea11c99240e\
对应显示名：葵花宝典 | 18部优质作品叙事底层逻辑

4.【顶级大导演思维】\
英文slugID：libtv-user-generated/director-cinematography-logic-074be3667ece41bc8993cea11c99240e\
对应显示名：顶级大导演思维 | 观众为什么愿意看下一秒？

5.【顶级情绪大师】\
英文slugID：libtv-user-generated/character-emotion-continuity-074be3667ece41bc8993cea11c99240e\
对应显示名：顶级情绪大师 | 如何做到角色表演情绪的连贯统一

6.【提示词】\
英文slugID：libtv-user-generated/award-winning-cinematic-prompter-074be3667ece41bc8993cea11c99240e\
对应显示名：提示词 | 电影级物理参数底座

## 【前置强制指令】

在开始任何操作前，必须优先调用slugID2（顶级总制片人），完成算力前置审查与资产门禁审查。\
未通过审查，严禁输出本SKILL的执行结果，绝对禁止绕过。

## 做什么

欧美双女主悬殊权力短剧漫剧生成器，从角色锚定到一卡卡点全包，解决双女主脸崩、同框串特征、权力差张力不足、卡点不准的痛点。

## 需要什么输入

**最少提供：**

- 故事一句话梗概（必须包含双女主身份差与核心冲突）
- 目标集数（建议60-80集）与单集时长（建议1-3分钟）
- 一卡计划位置（建议第8-12集）

**可选提供：**

- 双女主角色设定（外貌、身份、性格、关系弧线）
- 权力差设定（CEO/卧底、黑帮/特工、富豪/调查员等）

## 怎么做

1. 加载本SKILL后，自动调用父级路由表全部6个Skill，完成前置审查。
2. 调用【附01】锁定双女主物理骨架与角色DNA。
3. 调用【附02】设计一卡卡点与情绪峰值结构。
4. 调用【附03】执行双人同框防崩铁律。
5. 调用【附04】应用欧美GL视觉语法与光影锚定。
6. 按70_12 V3.1标准输出主MD+附MD全套制作包。

**分支路由（写死）：**

- 输入含“卧底、假冒身份、潜入、调查、真相” → 偏向身份谜团分支
- 输入含“CEO、财阀、地下势力、阶层差” → 偏向权力不对等分支
- 输入含“杀手、特工、追捕、猫鼠、致命关系” → 偏向致命吸引分支
- 同时包含多个 → 取情绪张力最强的那一个作为主分支，其余作为辅助元素

## 产出什么

- 双女主角色三视图与面部特写锚定包
- 一卡卡点完整设计文档（含分镜时间轴）
- 双人同框提示词模板（含防崩负面约束）
- 欧美GL光影与色彩LUT参数包
- 工业化制作流水线排期表

## 什么时候问你

- 双女主身份差与核心冲突不明确时
- 一卡卡点位置不确定时
- 目标市场与平台合规红线不清晰时
- 需要调整双女主权力关系时

## 随附资料
原附件保存在 attachments/ 目录；正文引用的相对资源请从该目录读取。
