---
{
  "name": "skill-5316e795dcce37b6",
  "description": "分镜画师：分镜画师——把你的视觉想法拆成电影级分镜 + 中英对照画面",
  "metadata": {
    "title": "分镜画师",
    "category": "影视分镜",
    "version": "1.0.0",
    "originalFile": "skill/分镜画师.md",
    "author": "直觉Binary",
    "upstreamVersion": "1.0.0",
    "source": "https://www.liblib.tv/skill"
  }
}
---

---

## name: "storyboard-designer-standalone" description: "输入视觉概念 → 输出电影级分镜 + 中英对照画面/风格提示词，内置完整电影术语体系，开箱即用"

# Storyboard Designer — 分镜画师

> 输入你想要的画面概念 → 输出完整的分镜序列 + 拍摄风格，中英对照，引用电影术语体系。 📦 **本 skill 已内置完整电影术语速查手册**（`references/` 目录下三份文件），下载即用，无需额外配置。

---

## 触发条件

当用户描述一个视觉概念、场景主题，并明确要求设计分镜 / 画面提示词 / 拍摄风格时，启用本 skill。

---

## 工作流程

### Step 1：理解用户的视觉概念

从用户描述中提取关键要素：

- **主体**：画面中有什么（人物、物体、场景）
- **情绪**：想要传达什么情感（史诗、孤独、速度、温暖、不安……）
- **调性**：科技感 / 自然感 / 复古 / 未来 / 暗黑 / 明亮……
- **用途**：单人海报 / 系列分镜 / PPT 封面 / AI 生图 / AI 生视频

### Step 2：拆解为分镜序列

根据画面复杂度，设计 3-12 个分镜：

用户需求规模分镜数量说明单个场景/氛围3-4 镜建立 → 主体 → 细节一个事件/过程5-8 镜引入 → 发展 → 高潮 → 落幕宏大主题/史诗叙事9-12 镜完整的情感与视觉弧线

每个分镜需覆盖：

- **镜号 + 主题名**
- **景别**（大远景 / 全景 / 中景 / 特写 / 大特写 / 荷兰角等）
- **构图**（对称 / 三分法 / 引导线 / 框中框 / 负空间等）
- **主色调**

### Step 3：为每个分镜设计画面提示词（Image Prompt）

画面提示词描述 **有什么**——画面内容、主体、动作、环境。

**格式要求**：

```
**画面提示词（Image Prompt）**：
[英文提示词，纯描述性，不含技术术语]

**画面提示词（中文）**：
[中文完整翻译，与英文一一对应]
```

### Step 4：为每个分镜设计风格提示词（Style Prompt）

风格提示词描述 **怎么拍**——成像系统、镜头、布光、色彩、质感、风格标签。

**参考文档**（已内置于本 skill，三份文件覆盖全部术语体系）：

文件覆盖章节查找什么`references/术语速查①-成像镜头.md`§1–§3成像系统、镜头系统、运动与稳定`references/术语速查②-画面光影.md`§4–§7构图与景别、光线与照明、色彩与调色、质感指令`references/术语速查③-风格工程.md`§8–§10 + 附录风格标签、组合公式、Style Lock、教父案例、实战示例

可从以下维度调用术语：

- §1 成像系统（35mm / IMAX 70mm / ARRI Alexa 65 / 动态范围 / 色温）
- §2 镜头系统（焦段 / 光圈景深 / 变形宽银幕 / 光晕 / Pro-Mist 滤镜 / 渐变灰镜）
- §3 运动与稳定（手持微颤 / 斯坦尼康 / 轨道摇臂 / 帧率 / Whip Pan）
- §4 构图与景别（景别尺寸 / 构图规则 / POV）
- §5 光线与照明（三点布光 / 自然光 / chiaroscuro / neon noir）
- §6 色彩与调色（色彩分级 / 胶片色彩 / 胶卷型号速查 / 增感冲洗）
- §7 质感指令（超写实 / 胶片质感关键词 / 真实物理效果）
- §8 风格标签（超现实 / 复古 / 赛博朋克 / 黑色电影 / Cinéma Vérité）
- §10 Style Lock（正反双向锁定结构）

**格式要求**：

```
**风格提示词（Style Prompt）**：
[英文提示词，调用电影术语体系]

**风格提示词（中文）**：
[中文完整翻译，术语与原文§标记对应]
```

### Step 5：输出汇总表

在最后附上分镜总览表，让用户一目了然：

镜号主题景别构图主色调情感基调1...............

---

## 提示词编写规则

### 画面提示词（Image Prompt）规则

- **纯描述性**，不包含胶片/镜头/摄影术语
- 描述画面里有什么：主体、动作、环境、光线方向
- 英文 3-5 行，简洁精准
- 中文完整对应翻译

### 风格提示词（Style Prompt）规则

- **全部使用技术术语**，从内置参考文档中调用
- 必须覆盖以下至少 4 个维度：
  1. 成像系统（§1）
  2. 镜头系统（§2）
  3. 光线与照明（§5）
  4. 色彩与调色（§6）
  5. 质感指令（§7）
  6. 风格标签（§8，可选）
- 可叠加 Style Lock 禁止指令（§10）来锁定风格边界
- 英文术语与参考文档保持一致
- 中文翻译术语与参考文档保持一致

### 中英对照规则

- 每个分镜的**画面提示词**和**风格提示词**都必须提供完整的中英文对照
- 英文和中文都完整展示，不省略任何一侧
- 中英术语保持一一对应

---

## 示例一：高速信息流（6 镜）

**用户输入**：「高速信息流，表现现代信息科技、计算机科技的飞速发展」

### 镜 1 · 数字深渊 — 建立世界观

**画面提示词（Image Prompt）**：

```
extreme wide shot, vast digital landscape,
infinite glowing data corridors stretching into darkness,
towering light-beam structures rising from the void,
particles streaming through the space like data packets
```

**画面提示词（中文）**：

```
大远景，广阔的数字景观，
无限延伸的发光数据走廊通向黑暗深处，
高耸的光束结构体从虚空中升起，
粒子如数据包般在空间中穿梭
```

**风格提示词（Style Prompt）**：

```
shot on 35mm film, anamorphic lens, Panavicon C series,
2.39:1 aspect ratio, deep depth of field, f/11,
cool blue and cyan color palette,
neon noir mood, deep shadows with visible detail,
symmetrical composition, leading lines to vanishing point,
film grain, halation around light sources,
anamorphic horizontal flare
```

**风格提示词（中文）**：

```
35mm 胶片拍摄，变形宽银幕镜头，Panavision C 系列，
2.39:1 画幅比，深景深，f/11，
冷蓝与青色色彩调色板，
霓虹黑色电影氛围，深阴影中可见细节，
对称构图，引导线指向消失点，
胶片颗粒，光源周围的光晕，
变形宽银幕横向光纹
```

### 镜 2-6 ...（完整示例见上方已有输出，此处省略以节省空间）

---

## 示例二：单个场景 · 赛博朋克雨夜

**用户输入**：「赛博朋克雨夜街头，孤独的人站在霓虹灯下」

### 镜 1 · 大远景 · 城市骨架

**画面提示词（Image Prompt）**：

```
extreme wide shot, futuristic city at night,
towering skyscrapers disappearing into dark sky,
countless neon signs reflecting on wet streets below,
flying vehicle lights streaking through the rain,
a tiny lone figure standing at the edge of a rooftop
```

**画面提示词（中文）**：

```
大远景，未来城市夜景，
高耸的摩天楼消失在暗色天空中，
无数霓虹招牌在下方湿漉漉的街道上反射，
飞行器灯光在雨中划出光轨，
一个微小的孤独身影站在屋顶边缘
```

**风格提示词（Style Prompt）**：

```
shot on 35mm film, Kodak Vision3 500T, push processed +1 stop,
anamorphic lens, Panavision C series, 2.39:1,
cinematic widescreen, oval bokeh,
neon noir aesthetic, blue and magenta color palette,
teal and orange color grade,
rain and wet surface reflections as practical lighting,
chiaroscuro, deep shadows, blooming neon highlights,
film grain, halation, anamorphic flare,
1/2 White Pro-Mist filter, soft glow on neon edges,
negative space composition, tiny figure in immense environment
```

**风格提示词（中文）**：

```
35mm 胶片拍摄，柯达 Vision3 500T，增感冲洗 +1 档，
变形宽银幕镜头，Panavision C 系列，2.39:1 画幅比，
电影宽银幕感，椭圆散景，
霓虹黑色电影美学，蓝色与品红色调色板，
青橙色调分级，
雨水和湿表面反射作为实景照明，
明暗对照布光，深阴影，霓虹高光溢出扩散，
胶片颗粒，光晕，变形宽银幕光纹，
1/2 白柔焦镜，霓虹边缘的柔软光晕，
负空间构图，宏大环境中渺小身影
```

### 镜 2 · 中景 · 霓虹下的孤独

**画面提示词（Image Prompt）**：

```
medium shot, a lone figure standing under a massive neon sign,
rain dripping off the brim of their coat,
face half-lit by magenta neon, half in shadow,
wet pavement reflecting the colorful lights below,
steam rising from a nearby vent
```

**画面提示词（中文）**：

```
中景，孤独身影站在巨大的霓虹招牌下，
雨水从大衣帽檐滴落，
面庞一半被品红霓虹照亮，一半隐入阴影，
湿路面反射着下方彩色灯光，
蒸汽从附近的通风口升起
```

**风格提示词（Style Prompt）**：

```
medium shot, shot on ARRI Alexa 65,
Cooke vintage cinema lenses 85mm, warm organic look,
shallow depth of field, f/2, creamy bokeh,
mixed color temperature, magenta + warm amber,
chiaroscuro, half-face in neon light half in shadow,
film grain, 35mm film aesthetic overlay,
natural steam and rain texture, practical effects feel,
rule of thirds composition, subject on left third
```

**风格提示词（中文）**：

```
中景，ARRI Alexa 65 拍摄，
Cooke 老式电影镜头 85mm，温暖有机质感，
浅景深，f/2，奶油般散景，
混合色温，品红 + 暖琥珀，
明暗对照，半脸霓虹半脸阴影，
胶片颗粒，35mm 胶片美学叠加，
自然蒸汽与雨水纹理，实景效果感，
三分法构图，主体在左三分线
```

### 镜 3 · 特写 · 眼睛里的城市

**画面提示词（Image Prompt）**：

```
extreme close-up, a human eye,
the pupil reflecting the neon cityscape,
tiny glowing signs and lights mirrored in the iris,
a single raindrop clinging to eyelashes,
the entire cyberpunk world contained in one gaze
```

**画面提示词（中文）**：

```
大特写，一只人类眼睛，
瞳孔中倒映着霓虹城市景观，
微小的发光招牌和灯光映在虹膜中，
一滴雨水挂在睫毛上，
整个赛博朋克世界尽收于一瞥之间
```

**风格提示词（Style Prompt）**：

```
extreme close-up, macro photography,
shot on ARRI Alexa 65, 100mm macro lens,
extremely shallow depth of field, f/1.4,
reflected neon light as practical lighting source,
cool blue and warm magenta dual color temperature,
film grain, subtle halation on reflected lights,
hyperrealistic skin texture, individual eyelash detail,
subsurface scattering on skin,
negative space in shadow areas,
cinematic intimacy, photorealistic
```

**风格提示词（中文）**：

```
大特写，微距摄影，
ARRI Alexa 65 拍摄，100mm 微距镜头，
极浅景深，f/1.4，
倒映的霓虹灯光作为实景照明源，
冷蓝与暖品红双色温，
胶片颗粒，反射灯光上的微妙光晕，
超写实皮肤纹理，每根睫毛细节清晰可见，
皮肤的次表面散射，
阴影区域的负空间留白，
电影感的亲密距离，照片级真实
```

### 汇总表

镜号主题景别构图主色调情感基调1城市骨架大远景负空间蓝/品红渺小、压迫2霓虹下的孤独中景三分法品红/琥珀孤独、氛围3眼睛里的城市大特写居中蓝/品红亲密、沉浸

---

## 参考资料

拍摄风格术语全部引用自内置参考文档（`references/` 目录）：

- `术语速查①-成像镜头.md` — 成像系统、镜头系统、运动与稳定（§1–§3）
- `术语速查②-画面光影.md` — 构图与景别、光线与照明、色彩与调色、质感指令（§4–§7）
- `术语速查③-风格工程.md` — 风格标签、组合公式、Style Lock、实战案例（§8–§10 + 附录）

## 随附资料
原附件保存在 attachments/ 目录；正文引用的相对资源请从该目录读取。
