---
{
  "name": "skill-0cd71867d7b6bcc3",
  "description": "分镜脚本生成器：输入主题时长风格，输出逐秒分镜脚本",
  "metadata": {
    "title": "分镜脚本生成器",
    "category": "影视分镜",
    "version": "1.0.0",
    "originalFile": "skill/分镜脚本生成器.md",
    "author": "Liana",
    "upstreamVersion": "1.0.0",
    "source": "https://www.liblib.tv/skill"
  }
}
---

```
```

```
---
name: 分镜脚本生成器
namespace: libtv-industry
title: "AIGC短视频分镜脚本生成器"
description: "输入主题+时长+风格，输出逐秒分镜脚本"
version: 1.0
---
# 分镜脚本生成器
## Skill 定位
- 只负责：把"想做个XX视频"的模糊需求，转成可直接AI生成/拍摄的逐秒分镜
- 不调用绘图/视频模型，只产出文本，零额外积分成本
## 输入
- 主题 / 时长 / 风格（三项必填）
## 内部流程和 Knowhow
- 按"前3秒钩子→展开→收尾"三段切秒数
- 每镜：镜号 / 秒数 / 画面描述 / 旁白 / BGM类型 / 音效
- 画面描述可直接喂MJ/即梦出图，附工具建议
- 自检：所有镜头秒数之和 = 总时长
## 输出
- 逐秒分镜表（文本）：镜号 / 秒数 / 画面 / 旁白 / 音乐
- 末尾附「可复用资产清单」：本片可直接复用的MJ提示词 × N、BGM类型 × N、钩子模板 × 1
## 自检
- 总时长对齐、每镜含画面+旁白、前3秒有钩子
## Ask User
- 风格或时长缺失时，先问再生成
```