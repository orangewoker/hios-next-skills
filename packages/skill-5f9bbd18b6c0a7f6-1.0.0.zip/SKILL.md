---
{
  "name": "skill-5f9bbd18b6c0a7f6",
  "description": "IPbear 浅珊瑚蜜桃粉毛绒小熊：IPbear 小熊换动作换场景，锁定角色一致性",
  "metadata": {
    "title": "IPbear 浅珊瑚蜜桃粉毛绒小熊",
    "category": "角色设计",
    "version": "1.0.0",
    "originalFile": "skill/IPbear 浅珊瑚蜜桃粉毛绒小熊.md",
    "author": "微信用户ea3d2d",
    "upstreamVersion": "1.0.8",
    "source": "https://www.liblib.tv/skill"
  }
}
---

---
name: ipbear
description: 使用技能包内置的六张原创角色参考图，为同一只浅珊瑚蜜桃粉三维毛绒小熊生成新动作、新场景或海报，并严格锁定角色身份、比例、五官、配色和短绒材质。用户提到 IPbear、小熊 IP 延展、换动作、换场景或保持该角色一致性时使用。
metadata:
  openclaw:
    emoji: "🧸"
---

# IPbear 角色一致性生成

只延展本技能包内的固定原创角色，不重新设计角色。动作、场景、道具、构图和镜头可以改变；角色身份、体量、五官、配色和毛发必须与六张原始参考图一致。

## 必须加载的素材

每次生成前都要完成以下准备：

1. 完整读取 references/character-style.md。
2. 完整读取 references/fixed-character-prompt.md。
3. 查看 `assets/reference-images/01.png` 至 `06.png`，确认它们展示的是同一个角色。
4. 使用 LibTV 当前项目中的图片生成或图片编辑流程，把本技能包内的原始图片作为角色参考输入。不能只靠文字重画角色，也不能用上一次生成图替代原始参考图。

如果当前节点不能读取或传入技能包内的参考图，停止生成并请用户把 `assets/reference-images/` 内的六张 PNG 上传到当前项目。不得退化为纯文字生成。

## 参考图分工

- `06.png`：正视站姿主标尺，负责整体高度、梨形体量、头脸占比、短腿与五官位置。
- `02.png`：倾斜站姿，负责动作后的无颈连续轮廓、短肢长度和腹部体量。
- `03.png`：侧视标尺，负责身体厚度、口鼻投影、手臂连接和尾巴位置。
- `04.png`：背视标尺，负责背部轮廓、臀部、腿距与单枚球形短尾巴。
- `05.png`：坐姿标尺，负责坐下时的腹部体量、腿脚厚度和面部一致性。
- `01.png`：趴卧标尺，负责低姿态、软体挤压和近景面部细节；不得用它的透视替代站姿比例。

六张图共同决定角色身份。按当前生成节点可用的参考图数量选择：

- 支持六张：`01.png` 至 `06.png` 全部使用。
- 最多支持五张：
  - 普通站立、行走和道具动作：`06.png`、`02.png`、`03.png`、`04.png`、`05.png`。
  - 趴卧、俯身或贴地动作：`01.png`、`02.png`、`03.png`、`05.png`、`06.png`。
- 最多支持三至四张：优先保留 `06.png`（正视主标尺）与 `03.png`（侧视标尺），再按动作补充——站姿类补 `04.png`，坐姿类补 `05.png`，趴卧类补 `01.png`；倾斜站姿 `02.png` 作为最后补充。
- 少于三张：停止生成，说明当前节点参考图数量不足以保证角色一致性，请用户更换支持更多参考图的节点。

图片与文字冲突时，以六张原始图片共同呈现的身份为准。角色只有一条短黑眉：在正视图中固定位于画面左侧（即角色自身的右侧）；禁止补成双眉，禁止左右镜像。

## LibTV 生成流程

1. 把用户请求拆为：场景、躯干方向、重心与支撑、视线、两臂方向、两腿方向、道具接触点、画幅和镜头。
2. 先建立与 `06.png` 一致的完整无颈梨形身体，再施加动作。不要先做普通大头熊再换材质。
3. 将两份参考文档中的角色定义、特征锁定、材质、颜色和负面约束，与用户要求的动作、场景和构图合并为一条生成指令。用户的文字只决定新动作和新场景，不得覆盖角色身份。
4. 在 LibTV 生成节点中明确标注：所附原始图片是唯一身份参考，决定解剖、脸、比例、毛发、颜色和材质；文字只决定新场景与动作。
5. 除非用户明确要求多个版本，先生成一个完整版本。生成后检查角色一致性；若主要项目不合格，仅针对最大偏差修正一次，修正时仍使用原始参考图。
6. 交付最终结果，并说明本次使用了哪些参考图以及是否经过修正。

## 生成指令结构

在两份参考文档的完整角色约束之前，加入以下信息：

```text
Use case: identity-preserve
Asset type: IPbear character scene/poster
Primary request: <用户的新场景与动作>
Input roles: <列出本次使用的原始参考图文件名及作用>
Pose and interaction: <躯干、重心、视线、双臂、双腿、支撑点、道具接触>
Composition: <画幅、景别、主体位置、留白>
Lighting and environment: <场景光线，但不得改变固有毛色>
Identity rule: the bundled original images are the only identity references. They exclusively determine the bear's anatomy, face, proportions, fur, colors and materials. The text request only determines the new scene and action.
Proportion lock: build the 06.png frontal pear-shaped body before posing; the lower torso stays wider and visually heavier than the upper face region; no visible neck; limbs remain short and thick.
Anatomy guard: exactly one bear, one head, two ears, two tapered fingerless arms, two short thick legs and at most one rear pom-pom tail; no fingers, claws, paw pads, long limbs, duplicate parts, broken joints or clipping.
Text: none unless the user supplies exact copy.
```

不得用“保持一致”之类一句话代替完整角色约束。

## 输出规格

- 画幅：默认 1:1 正方形，适合角色展示与海报主体；用户指定场景或海报时按其要求调整（如竖版 3:4、横版 16:9）。
- 数量：默认输出 1 张；用户明确要求多版本或多角度时才生成多张。
- 分辨率与质量：使用当前节点可用的最高质量设置，不主动降采样。
- 交付时一并说明本次使用的参考图、画幅和是否经过修正。

## 验收标准

只有以下项目全部通过才可交付：

- 身份：仍是参考图中的浅珊瑚蜜桃粉小熊，不是普通泰迪熊、棕熊或新角色。
- 轮廓：头身无颈相连，上窄下宽、厚实梨形；腹部宽于头脸区，不能变成独立球形大头、瘦腰或长腿。
- 五官：两只竖椭圆黑亮大眼与白色厚眼眶；仅一条短黑眉，正视图中位于画面左侧；奶油白紧凑口鼻垫；黑色爱心鼻；弧线笑嘴和小块珊瑚粉舌头。
- 耳尾：两只小圆耳配薄荷青绿内耳；尾巴最多一枚，位于臀后正中，受遮挡时可以不可见。
- 四肢：两臂宽根窄端、圆钝无指；腿脚短粗、无趾无肉垫；连接、遮挡与道具接触合理。
- 材质与颜色：全身统一为浅珊瑚蜜桃粉的 1–2 mm 短密植绒；不是长毛、卷毛、塑料、橡胶、黏土或湿亮材质；环境光不能造成明显毛色漂移。
- 场景：用户指定的动作、道具和环境清楚成立；没有多余角色、文字、Logo 或水印。

若头大身短，应整体缩小上部头脸区域并恢复更长、更宽的下部躯干，同时保持动作和场景不变；不要只缩小眼睛、只加宽肚子或拉长腿。若四肢或道具交互错误，用短而圆钝的无指手臂重新建立接触，不得通过生成手指来抓握。

## 随附资料
原附件保存在 attachments/ 目录；正文引用的相对资源请从该目录读取。
