---
{
  "name": "skill-46844ef5fc2881ae",
  "description": "商业人像Lookbook：精品级电商大片模特~注重皮肤质感",
  "metadata": {
    "title": "商业人像Lookbook",
    "category": "其他",
    "version": "1.0.0",
    "originalFile": "skill/商业人像Lookbook.md",
    "author": "弥茶子",
    "upstreamVersion": "1.0.2",
    "source": "https://www.liblib.tv/skill"
  }
}
---

---

## name: character-lookbook-v6 description: 电商服装Lookbook人物提示词生成专家 v6（商业人像级最终版）。基于 v5 修复 3 个未生效项：① T 区反光（删"natural sheen on T-zone"，改完全matte+显式否定）② 面部-身体色温断层（具体温度指令替代抽象"unified undertone"）③ 皮肤过于平滑（强化微纹理可见）。v6 是商业 KV / 小红书封面场景的最终稳定版。

# 人物Lookbook提示词生成 Skill v6（商业人像级最终版）

电商服装展示AI绘画提示词生成工具，**v6 重点修复 v5 未生效的 3 个关键点**。

---

## v6 变更日志（针对 v5 的修复）

#v5 未生效问题根因v6 修复1鼻子 T 区反光依然明显`minimal natural sheen only on T-zone` 中 "natural sheen" 被 AI 当成强提示覆盖了否定词❌ **删除 "natural sheen on T-zone"**，改写 `completely matte skin finish across entire face INCLUDING T-zone, nose bridge and forehead have NO shine NO reflection NO sheen`2面部-身体色温断层依然明显`UNIFIED UNDER TONE FAMILY` 太抽象，AI 不知道具体怎么做❌ **删除 "unified undertone family"**，改写 `face neck arms torso all share the SAME warm undertone temperature, no warm/cool shift between face and body, arm skin color temperature EXACTLY matches face skin color temperature`3皮肤过于完美平滑`hint of natural skin micro-texture` 表述太弱✅ 加强为 `natural skin micro-texture visible on cheeks and forehead, slight unevenness in skin surface, no airbrushed plastic smoothness`

> v6 的核心目标：让 v5 没生效的修复真正生效。3 项是商业 KV 从"能用"到"精品"的关键差距。

---

## v5 → v6 关键术语替换表

v5 写法（未生效）v6 写法`minimal natural sheen only on T-zone`❌ 删除整句`minimal natural sheen only on T-zone with no oily nose bridge reflection`❌ 删除整句`matte skin finish across cheeks jawline neck and body, minimal natural sheen only on T-zonecompletely matte skin finish across entire face including T-zone, nose bridge and forehead have NO shine NO reflection NO sheen, matte extends to neck and bodyUNIFIED UNDER TONE FAMILY across face neck arms torsoface neck arms torso all share the SAME warm undertone temperature, no warm/cool shift between face and bodyexposed arms with only subtle brightness difference from covered torso, UNIFIED UNDER TONE FAMILY across face neck arms torsoexposed arms color temperature EXACTLY matches face color temperature, no warm/cool shift between face and body, consistent warm undertone throughout visible skinhint of natural skin micro-texturenatural skin micro-texture visible on cheeks and forehead, slight unevenness in skin surface, no airbrushed plastic smoothnesssubtle refined pores barely visible at conversational distance, hint of natural skin micro-texturesubtle refined pores barely visible at conversational distance, natural skin micro-texture visible on cheeks and forehead, slight unevenness in skin surface, no airbrushed plastic smoothness`

---

## 一、功能概览（与 v5 一致）

维度可选值**人种**韩国 / 中国 / 日本 / 欧美 / 北欧 / 混血 / 非裔**年龄段**儿童 (4-12) / 青少年 (13-19) / 青年 (20-35) / 成熟 (36-55)**性别**女性 / 男性**身材**纤瘦型 / 标准型 / 健美型 / 运动健身体型**风格**清新甜系 / 极简高级 / 街头潮酷 / 松弛休闲 / 暗黑病娇 / 学院童趣 / 高级时装 / 文艺复古 / 新中式 / 港风复古 / 老钱风 / Y2K辣妹 / 通勤OL / 法式优雅 / 森系 / 赛博朋克**季节**春 / 夏 / 秋 / 冬**场景**封面主图 / 人物三视图 / 表情变化 / 身材比例分解 / 服装细节分解 / 五官高清特写 / 手臂皮肤特写 / 腿部皮肤特写 / 手部纹理特写 / 发丝细节特写 / 外景街拍 / 户外自然 / 中国特色场景 / 电商白底图 / 生活方式**妆容**韩系水光妆 / 韩系雾面瓷白妆 / 日系透明感裸妆 / 欧美修容雕塑妆 / 欧美自然裸妆 / 新中式古典妆 / 港风复古妆 / Y2K辣妹妆 / 法式慵懒妆 / 森系自然妆 / 赛博朋克未来妆 / 男性自然妆 / 韩系男模妆**真实感等级**电商基础级 / 人像真实级 / 电影质感级 / **商业人像级（电商封面级）** / 皮肤超真级**AI工具**Midjourney / Stable Diffusion / Flux / 全部适配**品牌模板**MLB / 优衣库 / ZARA / Old Money

---

## 二、使用方式（与 v5 一致）

---

## 三、高级功能

### 3.1 品牌风格模板（与 v5 一致）

### 3.2 真实感等级系统 ⭐v6 锁定「商业人像级」最终版

等级适用场景皮肤质感 ⭐v6 最终版痣 / 瑕疵光影 ⭐v6**电商基础级**商品主图、白底图平滑均匀0均匀柔光**人像真实级**人像特写毛孔可见，分区肤色过渡1-2 颗柔和棚光**电影质感级**品牌大片丰富纹理 + 强光影 + 胶片颗粒0-1 颗电影级布光⭐**商业人像级（电商封面级）** ⭐v6 锁定**小红书/电商封面KV/品牌主图completely matte across entire face INCLUDING T-zone（v6关键）/ natural skin micro-texture visible on cheeks and forehead（v6强化）/ subtle refined pores barely visible at conversational distance / arm skin color temperature EXACTLY matches face color temperature（v6关键）/ subtle natural warmth（无 blush）/ 分区域肤色过渡 / no moles / no visible blemishes / consistent warm undertone throughout visible skin0 颗痣 / 0 瑕疵soft directional commercial studio lighting with subtle side light, subtle chiaroscuro for three-dimensional facial structure, NOT flat frontal lighting, NOT passport photo lighting皮肤超真级**皮肤参考图、建模参考4K毛孔全脸均匀分布 + 跨区域肤色冷暖过渡 + 0-1 颗软边缘痣 + 微妙自然温暖感 + 次表面散射 + 唇纹细纹 + 雾面为主 + T区微光0-1 颗统一光源 + 侧光勾勒肌理

```
商业人像级 韩国女模 极简高级 夏季 封面主图    → 默认电商 KV 配方（v6 最终版）
皮肤超真级 韩国女模 五官高清特写              → 极致皮肤参考
电影质感级 中国女模 老钱风 冬季 街拍          → 杂志大片
```

---

### 3.3-3.5（与 v5 一致）

---

### 3.6 高清皮肤质感系统 ⭐v6 锁定版

11 大质感维度（v6 修订版）

维度v6 描述（关键词）适用等级**毛孔纹理** ⭐v6 强化`subtle refined pores barely visible at conversational distance, only visible on close inspection, natural skin micro-texture visible on cheeks and forehead, slight unevenness in skin surface, no airbrushed plastic smoothness, pores are healthy skin texture, visible but small and clean, NOT enlarged`全部**血管肌理**`subtle veins only on thin-skinned areas like wrists and inner arms, NOT prominent or blueish`全部**痣与色素**`OPTIONAL: 0 or 1 naturally occurring beauty mark. Default NO moles. Body: 0-1 small marks` ⭐ 商业人像级强制 0 颗痣全部**细绒毛**`fine vellus hair along hairline and sideburns, subtle and minimal, NOT visible on cheeks and forehead`全部**唇纹细纹**`natural lip lines, subtle under-eye fine lines only at outer eye corners, NOT across whole face`全部**雾面质感** ⭐v6 关键`completely matte skin finish across entire face INCLUDING T-zone, nose bridge and forehead have NO shine NO reflection NO sheen, matte extends to neck body and arms, natural skin surface, no oiliness, no dewy finish` ⭐ v6 关键：显式否定 T 区高光全部**次表面散射**`subtle subsurface scattering in shadow areas, natural micro-circulation color variation in thin skin areas like ears nostrils lips, soft color transitions between lit and shadowed skin`全部**皮肤褶皱**`natural knuckle / knee / elbow creases only when bent, neck horizontal lines, NO wrinkles on smooth skin areas`全部**肤色过渡** ⭐v6 关键`subtle natural skin tone variation with light zone differences: T-zone slightly cooler than surrounding areas, cheek apples slightly warmer than jawline, neck slightly cooler than face, face neck arms torso all share the SAME warm undertone temperature, no warm/cool shift between face and body, consistent warm undertone throughout visible skin, arm skin color temperature EXACTLY matches face skin color temperature, no body-face color temperature mismatch, no circular color patches on cheeks` ⭐ v6 关键：SAME warm undertone temperature + EXACTLY matches全部**腮红/红晕**`subtle natural warmth on cheek apples, NOT pronounced blush, NOT rosy cheeks, NOT circular red patches, NOT stamped-on color, only natural micro-circulation undertone variation, no obvious cheek color blocks`全部**统一光源**`consistent single soft directional light source from upper left across all panels, subtle side light to define jawline cheekbone and nasal-labial fold, matching shadow angles, soft chiaroscuro for three-dimensional facial structure, NOT flat frontal lighting, NOT passport photo lighting`全部**跨区域一致性** ⭐v6 关键`body-face skin texture and undertone consistency: face neck exposed arms visible torso all share same refined skin quality AND face neck arms torso all share the SAME warm undertone temperature, no body-face color temperature mismatch, no patchwork skin coloring, NO plastic mannequin color uniformity`全部

---

### 3.7 负面提示词标准库 ⭐v6 强化 Layer 1

皮肤相关场景**必须**包含 7 层负面提示词：

**Layer 1 - 反油光/T 区反光核心词 ⭐v6 强化**：

```
glossy skin, oily face, dewy skin, glowing complexion, oil sheen, shiny face, shiny skin,
plastic skin, porcelain skin, ceramic skin, silicone skin, waxy texture, mannequin,
oily nose, shiny nose bridge, oily T-zone, shiny T-zone, oily forehead, shiny forehead,
nose highlight reflection, T-zone highlight reflection,
matte T-zone violation, T-zone sheen, forehead shine, nose tip shine,
glossy nose bridge, glossy forehead, dewy T-zone, dewy nose
```

**Layer 2 - 反过度完美词**：

```
smooth flawless skin, no pores, smooth skin without texture, plastic smooth face, rubber skin,
perfect symmetrical face, evenly distributed freckles, uniform mole pattern,
over-retouched, airbrushed, doll-like, uncanny valley, passport photo skin, ID photo skin,
airbrushed plastic smoothness, completely smooth skin surface, no skin texture
```

**Layer 3 - 反瑕疵过多词**： （与 v5 一致）

**Layer 4 - 反 AI 痕迹词**： （与 v5 一致）

**Layer 5 - 反塑料皮/反色温断层词 ⭐v6 强化**：

```
uniform single skin tone, monochrome skin, mannequin color, plastic skin tone,
waxy uniform complexion, flat skin color, no undertone variation,
no color gradient on skin, monochrome body coloring, synthetic skin appearance,
one-tone body color, t-shirt doll skin, department store mannequin skin,
no zone-to-zone skin variation, flat color block skin,
body face color mismatch, face body color temperature difference,
face-body undertone mismatch, patchwork skin coloring,
face pink body yellow, face cool body warm, body darker than face, body lighter than face,
visible color boundary between face and body, seam between face and body
```

**Layer 6 - 反腮红妆容词**： （与 v5 一致）

**Layer 7 - 反碎发/反凌乱**： （与 v5 一致）

---

### 3.8 电商/小红书 KV 专属 Prompt 模板 ⭐v6 最终版

**适用场景**：电商封面、小红书封面、品牌主图

**核心配方 v6 完整版**：

```
【配置信息】
人种：[人种] / 年龄段：青年 (20-35) / 性别：[性别] / 身材：标准型
风格：[风格] / 季节：[季节] / 场景：[封面主图/电商白底图/外景街拍]
AI工具：Midjourney / 真实感：商业人像级（电商封面级）v6
妆容：[自动匹配 + 弱化处理]

【英文Prompt】
[人物基础描述]，[穿搭]，[姿态]，[背景]，

[品牌调性关键词：editorial / commercial / clean fashion photography / campaign style / modern minimal / refined]

subtle refined pores barely visible at conversational distance,
natural skin micro-texture visible on cheeks and forehead, slight unevenness in skin surface, no airbrushed plastic smoothness,
completely matte skin finish across entire face INCLUDING T-zone, nose bridge and forehead have NO shine NO reflection NO sheen, matte extends to neck body and arms,
subtle natural warmth on cheek apples, NOT pronounced blush, NOT rosy cheeks, NOT circular red patches, NOT stamped-on color, only natural micro-circulation undertone variation, no obvious cheek color blocks,
subtle natural skin tone variation with light zone differences: T-zone slightly cooler than surrounding areas, cheek apples slightly warmer than jawline, neck slightly cooler than face,
face neck arms torso all share the SAME warm undertone temperature, no warm/cool shift between face and body, consistent warm undertone throughout visible skin, arm skin color temperature EXACTLY matches face skin color temperature,
body-face skin texture and undertone consistency: face neck exposed arms visible torso all share same refined skin quality AND same warm undertone,
subsurface scattering in shadow areas, subtle warmth in thin skin areas like ears nostrils lips,
fine vellus hair along hairline and sideburns only,
no moles on face, no moles on body,
natural lip texture, no prominent under-eye lines,
polished hair with minimal natural flyaways, neat hairstyle, NOT messy, NOT frizzy,
consistent single soft directional light source from upper left, matching shadow angles,
subtle side light to define jawline cheekbone and nasal-labial fold,
soft directional commercial studio lighting with subtle chiaroscuro for three-dimensional facial structure, NOT flat frontal lighting, NOT passport photo lighting,
photorealistic, clean commercial fashion photography, editorial minimal,
shot on Hasselblad H6D, 80mm, f/4
--ar 3:4 --style raw --v 6.1 --stylize 100

【负面提示词（7 层）】
Layer 1 - anti-shine/T-zone（v6 强化）:
glossy skin, oily face, dewy skin, oil sheen, shiny face, plastic skin, porcelain skin, silicone skin, mannequin, oily nose, shiny nose bridge, oily T-zone, shiny T-zone, oily forehead, shiny forehead, nose highlight reflection, T-zone highlight reflection, T-zone sheen, forehead shine, nose tip shine, glossy nose bridge, glossy forehead, dewy T-zone

Layer 2 - anti-perfection:
smooth flawless skin, no pores, airbrushed, doll-like, perfect symmetrical face, over-retouched, passport photo skin, ID photo skin, airbrushed plastic smoothness, no skin texture

Layer 3 - anti-blemish:
acne, pimples, blemishes, more than 1 mole on face, mole covered face, stamped moles, freckles everywhere, stamped on moles, drawn on moles

Layer 4 - anti-AI:
CGI, 3d render, cartoon, anime, painting, illustration, heavy foundation, thick concealer, false lashes, contour makeup

Layer 5 - anti-monochrome / color-temp-mismatch（v6 强化）:
uniform single skin tone, monochrome skin, mannequin color, flat skin color, no undertone variation, synthetic skin appearance, body face color mismatch, face body color temperature difference, patchwork skin coloring, face pink body yellow, face cool body warm, visible color boundary between face and body

Layer 6 - anti-blush:
strong blush, rosy cheeks, circular blush, blush circles, blush patches, sun blush, sunburn look, red cheeks, cheek color blocks, rouge, blush gradient on cheeks

Layer 7 - anti-flyaway:
excessive flyaway hair, frizzy hair, messy hair, unkempt hair, wild flyaways, scattered flyaway strands, hair halo
```

---

## 四、场景说明（与 v5 一致）

---

## 五、输出格式（v6 微调：7 层负面词 + T 区/色温/微纹理强化）

```
【配置信息】
人种：韩国 / 年龄段：青年 / 性别：女性 / 身材：标准型
风格：极简高级 / 季节：夏季 / 场景：封面主图
真实感：商业人像级（电商封面级）v6

【英文Prompt】
[完整 v6 商业 KV 配方]

【负面提示词（7 层）】
[完整 v6 7 层负面词]

【中文说明】
【真实感】商业人像级 v6 · 完全 matte（含 T 区）/ SAME warm undertone / 微纹理可见 / 7 层负面词
```

---

## 六、常用指令速查（与 v5 一致）

---

## 七、数据文件说明

```
character-lookbook-skill/
├── SKILL.md                    # 主文件（v6）
├── SKILL_v5.md                 # v5 旧版（保留归档）
├── SKILL_v4.md
├── SKILL_v3.md
├── SKILL_v2.md
├── data/
│   ├── character-bases.js
│   ├── style-outfits.js
│   ├── brand-styles.js
│   ├── scene-templates.js
│   ├── realism-kit-v6.js       # v6：T 区 matte / SAME warm undertone / 微纹理
│   ├── skin-texture-kit-v6.js  # v6：完全 matte + 微纹理 + 色温一致
│   ├── kv-templates-v6.js      # v6：商业 KV 最终模板
│   └── prompt-engine.js
└── references/
```

---

## 八、适配说明（与 v5 一致）

---

## 九、拆解模式详细说明（与 v5 一致）

---

## 十、皮肤质感调优经验总结 ⭐v6 扩充

#经验说明1-16（继承 v5）同 v5 经验17⭐v6 新增：**"natural sheen on T-zone" 是陷阱词**一旦写"natural sheen"AI 会先执行 sheen，再用否定词无效。商业 KV 完全不要写 sheen/glow/oil，改写 "completely matte INCLUDING T-zone" + 显式 "NO shine NO reflection NO sheen"18⭐v6 新增：**"unified undertone family" 太抽象**AI 不知道具体怎么做。改写 `face neck arms torso all share the SAME warm undertone temperature` + `arm skin color temperature EXACTLY matches face skin color temperature` 用 EXACTLY 加强19⭐v6 新增：**"hint of micro-texture" 太弱**改写 `natural skin micro-texture visible on cheeks and forehead, slight unevenness in skin surface` 才能让微纹理真的出现20⭐v6 新增：**色温断层负面词要具体**只写 `body face color mismatch` 不够。加 `face pink body yellow, face cool body warm, visible color boundary between face and body, seam between face and body`

---

现在，请告诉我你想要生成什么样的人物 lookbook？可以直接用自然语言描述，回复"开始"进入选项式交互，或回复"拆解 + 描述"一键生成全维度细节参考图。